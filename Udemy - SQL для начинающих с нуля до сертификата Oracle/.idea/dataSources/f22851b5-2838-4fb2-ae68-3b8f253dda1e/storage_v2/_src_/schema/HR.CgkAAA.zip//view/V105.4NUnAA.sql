create view V105 as
SELECT SUBSTR(NAME, 2
           ) name,
       COURSE
FROM STUDENTS
/

