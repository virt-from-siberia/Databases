create view V202 as
SELECT *
FROM STUDENTS2
/

