create materialized view mvw_loan_balances2 as
WITH calendar AS (
    SELECT generate_series('2021-11-01 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '1 day'::interval)::date AS check_dt
),
     loan_pays AS (
         SELECT tmp_account_history.loan_id,
                (tmp_account_history.added_at + '03:00:00'::interval)::date AS trans_date,
                sum(tmp_account_history.record_sum)                         AS amount
         FROM tmp_account_history
         WHERE tmp_account_history.type_record_id <> 1
           AND (tmp_account_history.method::text = ANY
                (ARRAY ['mandarinpay'::character varying, 'tinkoff'::character varying, 'cash'::character varying, 'cashless_payment'::character varying, 'unknown'::character varying]::text[]))
         GROUP BY tmp_account_history.loan_id, ((tmp_account_history.added_at + '03:00:00'::interval)::date)
     ),
     loan_in_ca AS (
         SELECT a.loan_id,
                a.transfer_ca_dt::date     AS transfer_ca_dt,
                COALESCE(lead(a.receive_ca_dt::date) OVER (PARTITION BY a.loan_id ORDER BY a.created_at),
                         CURRENT_DATE + 1) AS receive_ca_dt
         FROM (SELECT ct.loan_id,
                      CASE
                          WHEN ct.comment = 'Договор передан в коллекторское агентство "ООО «АйДи Коллект»"'::text
                              THEN ct.created_at
                          ELSE NULL::timestamp without time zone
                          END AS transfer_ca_dt,
                      CASE
                          WHEN ct.comment = 'Договор отозван из коллекторского агентства "ООО «АйДи Коллект»"'::text
                              THEN ct.created_at
                          ELSE NULL::timestamp without time zone
                          END AS receive_ca_dt,
                      ct.created_at
               FROM collector_tasks ct
                        JOIN loans l ON ct.loan_id = l.loan_id
               WHERE ct.comment = ANY
                     (ARRAY ['Договор передан в коллекторское агентство "ООО «АйДи Коллект»"'::text, 'Договор отозван из коллекторского агентства "ООО «АйДи Коллект»"'::text])) a
     ),
     existence_loans AS (
         SELECT DISTINCT calendar.check_dt,
                         mlb_1.loan_id
         FROM calendar
                  LEFT JOIN mvw_loan_balances mlb_1
                            ON calendar.check_dt >= mlb_1.start_status AND calendar.check_dt <= mlb_1.stop_status
     )
SELECT existence_loans.check_dt,
       existence_loans.loan_id,
       CASE
           WHEN mlb.check_dt IS NOT NULL THEN mlb.status_name
           WHEN mlb.check_dt IS NULL AND mlb_prev.check_dt IS NOT NULL AND mlb_next.check_dt IS NOT NULL
               THEN mlb_prev.status_name
           ELSE NULL::loansstatusenum
           END AS status_name,
       CASE
           WHEN mlb.check_dt IS NOT NULL THEN mlb.status_id_overdue
           WHEN mlb.check_dt IS NULL AND mlb_prev.check_dt IS NOT NULL AND mlb_next.check_dt IS NOT NULL
               THEN mlb_prev.status_id_overdue
           ELSE NULL::text
           END AS status_id_overdue,
       CASE
           WHEN mlb.check_dt IS NOT NULL THEN mlb.principal_debt
           WHEN mlb.check_dt IS NULL AND mlb_prev.check_dt IS NOT NULL AND mlb_next.check_dt IS NOT NULL
               THEN mlb_prev.principal_debt
           ELSE NULL::numeric
           END AS principal_debt,
       CASE
           WHEN mlb.check_dt IS NOT NULL THEN mlb.interest_debt
           WHEN mlb.check_dt IS NULL AND mlb_prev.check_dt IS NOT NULL AND mlb_next.check_dt IS NOT NULL
               THEN mlb_prev.interest_debt
           ELSE NULL::numeric
           END AS interest_debt,
       CASE
           WHEN mlb.check_dt IS NOT NULL THEN mlb.service_debt
           WHEN mlb.check_dt IS NULL AND mlb_prev.check_dt IS NOT NULL AND mlb_next.check_dt IS NOT NULL
               THEN mlb_prev.service_debt
           ELSE NULL::numeric
           END AS service_debt,
       loan_pays.amount,
       CASE
           WHEN loan_in_ca.loan_id IS NOT NULL THEN 'Да'::text
           ELSE 'Нет'::text
           END AS loan_in_ca,
       CASE
           WHEN existence_loans.check_dt = min(existence_loans.check_dt)
                                           FILTER (WHERE mlb.status_name = 'loan_overdue'::loansstatusenum) OVER (PARTITION BY existence_loans.loan_id)
               THEN min(existence_loans.check_dt) OVER (PARTITION BY existence_loans.loan_id)
           ELSE NULL::date
           END AS open_dt_collect,
       CASE
           WHEN existence_loans.check_dt = min(existence_loans.check_dt)
                                           FILTER (WHERE mlb.status_name = 'loan_overdue'::loansstatusenum) OVER (PARTITION BY existence_loans.loan_id)
               THEN mlb.principal_debt
           ELSE NULL::numeric
           END AS issue_sum_collect,
       mlb.cession_dt,
       mlb.forced_closure_dt
FROM existence_loans
         LEFT JOIN mvw_loan_balances mlb
                   ON existence_loans.check_dt = mlb.check_dt AND existence_loans.loan_id = mlb.loan_id
         LEFT JOIN mvw_loan_balances mlb_prev
                   ON existence_loans.check_dt = (mlb_prev.check_dt + 1) AND existence_loans.loan_id = mlb_prev.loan_id
         LEFT JOIN mvw_loan_balances mlb_next
                   ON existence_loans.check_dt = (mlb_next.check_dt - 1) AND existence_loans.loan_id = mlb_next.loan_id
         LEFT JOIN loan_pays
                   ON existence_loans.check_dt = loan_pays.trans_date AND existence_loans.loan_id = loan_pays.loan_id
         LEFT JOIN loan_in_ca
                   ON existence_loans.loan_id = loan_in_ca.loan_id AND loan_in_ca.transfer_ca_dt IS NOT NULL AND
                      existence_loans.check_dt >= loan_in_ca.transfer_ca_dt AND
                      existence_loans.check_dt <= loan_in_ca.receive_ca_dt;

alter materialized view mvw_loan_balances2 owner to "pz-zeppelin";

create index ix_mvw_lbalance2_loan_id
    on mvw_loan_balances2 (loan_id);

