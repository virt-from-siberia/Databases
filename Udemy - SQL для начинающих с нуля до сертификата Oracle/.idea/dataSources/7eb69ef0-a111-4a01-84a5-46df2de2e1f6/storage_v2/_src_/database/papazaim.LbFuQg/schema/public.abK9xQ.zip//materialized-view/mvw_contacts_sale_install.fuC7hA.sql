create materialized view mvw_contacts_sale_install as
WITH last_statuses AS (
    SELECT DISTINCT ON (ls.loan_id) ls.loan_id,
                                    ls.status_name
    FROM loan_statuses ls
             JOIN loan_statuses_pk_map lspm ON ls.status_id = lspm.pz_id
    WHERE ls.is_deleted IS FALSE
    ORDER BY ls.loan_id, lspm.sc_id DESC
),
     last_close_ppz AS (
         SELECT DISTINCT ON ((l_1.user_id::text)) l_1.user_id,
                                                  CURRENT_DATE - (ls.status_date + '03:00:00'::interval)::date AS day_after_cls
         FROM loan_statuses ls
                  JOIN loans l_1 ON l_1.loan_id = ls.loan_id AND l_1.loan_sum IS NOT NULL
         WHERE ls.status_name = 'closed'::loansstatusenum
         ORDER BY (l_1.user_id::text), ls.status_date DESC
     ),
     analit_response AS (
         SELECT DISTINCT ON ((ns.user_id::text)) ns.user_id,
                                                 CASE
                                                     WHEN (ns.accounts_count - ns.active_accounts_count) < 10 THEN 0
                                                     WHEN (ns.accounts_count - ns.active_accounts_count) >= 10 AND
                                                          (ns.accounts_count - ns.active_accounts_count) < 30 THEN 1
                                                     WHEN (ns.accounts_count - ns.active_accounts_count) >= 30 AND
                                                          (ns.accounts_count - ns.active_accounts_count) < 100 THEN 2
                                                     WHEN (ns.accounts_count - ns.active_accounts_count) >= 100 THEN 3
                                                     ELSE 0
                                                     END AS idx_closed_loans,
                                                 CASE
                                                     WHEN lcp.day_after_cls < 7 THEN 3
                                                     WHEN lcp.day_after_cls >= 7 AND lcp.day_after_cls < 14 THEN 2
                                                     WHEN lcp.day_after_cls >= 14 AND lcp.day_after_cls < 30 THEN 1
                                                     ELSE 0
                                                     END AS idx_day_after_cls,
                                                 CASE
                                                     WHEN ns.last_7_days_requests_count = 0 THEN 0
                                                     WHEN ns.last_7_days_requests_count >= 1 AND ns.last_7_days_requests_count < 3
                                                         THEN 1
                                                     WHEN ns.last_7_days_requests_count >= 3 AND ns.last_7_days_requests_count < 6
                                                         THEN 2
                                                     WHEN ns.last_7_days_requests_count >= 6 THEN 3
                                                     ELSE 0
                                                     END AS idx_last_7_days_requests_count
         FROM nbki_scoring ns
                  LEFT JOIN last_close_ppz lcp ON lcp.user_id = ns.user_id
         ORDER BY (ns.user_id::text), ns.requested_at DESC
     )
SELECT l.user_id,
       max(date_part('year'::text, age(CURRENT_DATE::timestamp without time zone, p.date_of_birth)))       AS age,
       max(p.gender::text)                                                                                 AS gender,
       max((((p.last_name::text || ' '::text) || p.first_name::text) || ' '::text) || p.middle_name::text) AS fio,
       max(p.date_of_birth)::date                                                                          AS date_of_birth,
       max(k.city::text)                                                                                   AS city,
       max(u.time_zone::text)                                                                              AS time_zone,
       max(pn.number::text)                                                                                AS number_phon,
       array_agg(lst1.status_name)                                                                         AS all_statuses,
       COALESCE(max(ar.idx_closed_loans), 0) + COALESCE(max(ar.idx_day_after_cls), 0) +
       COALESCE(max(ar.idx_last_7_days_requests_count), 0) + COALESCE(
               CASE
                   WHEN array_agg(lst1.status_name) @> '{closed}'::loansstatusenum[] THEN 10
                   ELSE 0
                   END,
               0)                                                                                          AS priority_points
FROM loans l
         JOIN users u ON u.user_id = l.user_id
         JOIN passport p ON p.user_id = l.user_id
         JOIN kladr k ON p.actual_address_id = k.id AND
                         (k.city::text ~~* '%Москва%'::text OR k.city::text ~~* '%Мытищи%'::text OR
                          k.city::text ~~* '%Лобня%'::text OR k.city::text ~~* '%Долгопрудный%'::text OR
                          k.city::text ~~* '%Дмитров%'::text OR k.city::text ~~* '%Химки%'::text OR
                          k.city::text ~~* '%Красногорск%'::text OR k.city::text ~~* '%Наро-Фоминск%'::text OR
                          k.city::text ~~* '%Люберцы%'::text OR k.city::text ~~* '%Королев%'::text OR
                          k.city::text ~~* '%Щелково%'::text OR k.city::text ~~* '%Одинцово%'::text OR
                          k.city::text ~~* '%Московский%'::text OR k.city::text ~~* '%Тверь%'::text OR
                          k.city::text ~~* '%Ржев%'::text OR k.city::text ~~* '%Вышний Волочек%'::text OR
                          k.city::text ~~* '%Торжок%'::text OR k.city::text ~~* '%Смоленск%'::text OR
                          k.city::text ~~* '%Орел%'::text OR k.city::text ~~* '%Брянск%'::text OR
                          k.city::text ~~* '%Климов%'::text OR k.city::text ~~* '%Белгород%'::text OR
                          k.city::text ~~* '%Старый Оскол%'::text OR k.city::text ~~* '%Курск%'::text OR
                          k.city::text ~~* '%Курчатов%'::text OR k.city::text ~~* '%Санкт-Петербург%'::text OR
                          k.city::text ~~* '%Ломоносов%'::text OR k.city::text ~~* '%Петергоф%'::text OR
                          k.city::text ~~* '%Волгоград%'::text OR k.city::text ~~* '%Волжский%'::text OR
                          k.city::text ~~* '%Краснослободск%'::text OR k.city::text ~~* '%Городище%'::text OR
                          k.city::text ~~* '%Светлый яр%'::text OR k.city::text ~~* '%Новороссийск%'::text OR
                          k.city::text ~~* '%Анапа%'::text OR k.city::text ~~* '%Геленджик%'::text OR
                          k.city::text ~~* '%Ростов-на-Дону%'::text OR k.city::text ~~* '%Таганрог%'::text OR
                          k.city::text ~~* '%Сальск%'::text OR k.city::text ~~* '%Ейск%'::text OR
                          k.city::text ~~* '%Ставрополь%'::text OR k.city::text ~~* '%Изобильный%'::text OR
                          k.city::text ~~* '%Михайловск%'::text OR k.city::text ~~* '%Екатеринбург%'::text OR
                          k.city::text ~~* '%Каменск-Уральский%'::text OR k.city::text ~~* '%Нижний Тагил%'::text OR
                          k.city::text ~~* '%Первоуральск%'::text OR k.city::text ~~* '%Ревда%'::text OR
                          k.city::text ~~* '%Берёзовский%'::text OR k.city::text ~~* '%Верхняя Пышма%'::text OR
                          k.city::text ~~* '%Среднеуральск%'::text OR k.city::text ~~* '%Богданович%'::text OR
                          k.city::text ~~* '%Сухой Лог%'::text OR k.city::text ~~* '%Сысерть%'::text OR
                          k.city::text ~~* '%Арамиль%'::text OR k.city::text ~~* '%Артёмовский%'::text OR
                          k.city::text ~~* 'Реж'::text OR k.city::text ~~* '%Верхняя Салда%'::text OR
                          k.city::text ~~* '%Нижняя Салда%'::text OR k.city::text ~~* '%Верхняя Тура%'::text OR
                          k.city::text ~~* '%Красноуральск%'::text OR k.city::text ~~* '%Кушва%'::text OR
                          k.city::text ~~* '%Качканар%'::text OR k.city::text ~~* '%Новоуральск%'::text OR
                          k.city::text ~~* '%Невьянск%'::text OR k.city::text ~~* '%Кировград%'::text OR
                          k.city::text ~~* '%Верхний Тагил%'::text OR k.city::text ~~* '%Нижние Серьги%'::text OR
                          k.city::text ~~* '%Верхние Серьги%'::text OR k.city::text ~~* '%Дегтярск%'::text OR
                          k.city::text ~~* '%Бисерть%'::text OR k.city::text ~~* '%Дружинино%'::text OR
                          k.city::text ~~* '%Миасс%'::text OR k.city::text ~~* '%Чебаркуль%'::text OR
                          k.city::text ~~* '%Златоуст%'::text OR k.city::text ~~* '%Пермь%'::text OR
                          k.city::text ~~* '%Краснокамск%'::text OR k.city::text ~~* '%Кунгур%'::text OR
                          k.city::text ~~* '%Чусовой%'::text OR k.city::text ~~* '%Лысьва%'::text OR
                          k.city::text ~~* '%Тюмень%'::text OR k.city::text ~~* '%Оренбург%'::text OR
                          k.city::text ~~* '%Омск%'::text OR k.city::text ~~* '%Тольятти%'::text OR
                          k.city::text ~~* '%Сызрань%'::text OR k.city::text ~~* '%Саратов%'::text OR
                          k.city::text ~~* '%Курган%'::text OR k.city::text ~~* '%Шадринск%'::text OR
                          k.city::text ~~* '%Далматово%'::text OR k.city::text ~~* '%Катайск%'::text OR
                          k.city::text ~~* '%Барнаул%'::text OR k.city::text ~~* '%Бийск%'::text OR
                          k.city::text ~~* '%Красноярск%'::text OR k.city::text ~~* '%Сосновоборск%'::text OR
                          k.city::text ~~* '%Новосибирск%'::text OR k.city::text ~~* '%Бердск%'::text OR
                          k.city::text ~~* '%Искитим%'::text OR k.city::text ~~* '%Краснообск%'::text OR
                          k.city::text ~~* '%Энгельс%'::text OR k.city::text ~~* '%Иваново%'::text OR
                          k.city::text ~~* '%Кохма%'::text OR k.city::text ~~* '%Шуя%'::text OR
                          k.city::text ~~* '%Фурманов%'::text OR k.city::text ~~* '%Вичуга%'::text OR
                          k.city::text ~~* '%Приволжск%'::text OR k.city::text ~~* '%Родники%'::text OR
                          k.city::text ~~* '%Тейково%'::text OR k.city::text ~~* '%Калуга%'::text OR
                          k.city::text ~~* '%Балабаново%'::text OR k.city::text ~~* '%Белоусово%'::text OR
                          k.city::text ~~* '%Боровск%'::text OR k.city::text ~~* '%Ермолино%'::text OR
                          k.city::text ~~* '%Таруса%'::text OR k.city::text ~~* '%Жуков%'::text OR
                          k.city::text ~~* '%Козельск%'::text OR k.city::text ~~* '%Кондрово%'::text OR
                          k.city::text ~~* '%Малоярославец%'::text OR k.city::text ~~* '%Медынь%'::text OR
                          k.city::text ~~* '%Обнинск%'::text OR k.city::text ~~* '%Сосенский%'::text OR
                          k.city::text ~~* '%Сухиничи%'::text OR k.city::text ~~* '%Таруса%'::text OR
                          k.city::text ~~* '%Воронеж%'::text OR k.city::text ~~* '%Семилуки%'::text OR
                          k.city::text ~~* '%Новая установка%'::text OR k.city::text ~~* '%Отрадное%'::text OR
                          k.city::text ~~* '%Армавир%'::text OR k.city::text ~~* '%Курганинск%'::text OR
                          k.city::text ~~* '%Кропоткин%'::text OR k.city::text ~~* '%Гулькевичи%'::text OR
                          k.city::text ~~* '%Новокубанск%'::text OR k.city::text ~~* '%Лабинск%'::text OR
                          k.city::text ~~* '%пгт.Мостовской%'::text OR k.city::text ~~* '%Успенское%'::text OR
                          k.city::text ~~* '%Коноково%'::text OR k.city::text ~~* '%Вольное%'::text OR
                          k.city::text ~~* '%Родниковская%'::text OR k.city::text ~~* '%Убеженская%'::text OR
                          k.city::text ~~* '%Мурманск%'::text OR k.city::text ~~* '%Петрозаводск%'::text OR
                          k.city::text ~~* '%Архангельск%'::text OR k.city::text ~~* '%Владимир%'::text OR
                          k.city::text ~~* '%Ковров%'::text OR k.city::text ~~* '%Муром%'::text) AND
                         (k.city::text !~~* '%обл%'::text OR k.city::text !~~* '%край%'::text OR
                          k.city::text !~~* '%респ%'::text)
         JOIN phone_numbers pn ON pn.user_id = l.user_id AND pn.is_default IS TRUE AND pn.is_active IS TRUE
         JOIN last_statuses lst1 ON l.loan_id = lst1.loan_id AND (lst1.status_name = ANY
                                                                  (ARRAY ['closed'::loansstatusenum, 'underwriter_refusal'::loansstatusenum, 'client_refusal'::loansstatusenum]))
         LEFT JOIN (SELECT l2.user_id
                    FROM loans l2
                             JOIN last_statuses lst2 ON l2.loan_id = lst2.loan_id AND (lst2.status_name = ANY
                                                                                       (ARRAY ['loan_repayment_date'::loansstatusenum, 'loan_extended'::loansstatusenum, 'loan_overdue'::loansstatusenum, 'loan_issued'::loansstatusenum]))) al
                   ON al.user_id = l.user_id
         LEFT JOIN (SELECT l3.user_id
                    FROM loan_statuses ls2
                             JOIN loans l3 ON l3.loan_id = ls2.loan_id
                    WHERE ls2.is_deleted IS FALSE
                      AND (ls2.status_name = ANY
                           (ARRAY ['cession'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum]))) bc
                   ON bc.user_id = l.user_id
         LEFT JOIN (SELECT a.user_id
                    FROM (SELECT l4.user_id,
                                 array_agg(ls3.status_name) AS stss
                          FROM loan_statuses ls3
                                   JOIN loans l4 ON l4.loan_id = ls3.loan_id AND (l4.product_id = ANY
                                                                                  (ARRAY ['fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
                          WHERE ls3.is_deleted IS FALSE
                            AND (ls3.status_name = ANY
                                 (ARRAY ['underwriter_refusal'::loansstatusenum, 'closed'::loansstatusenum]))
                          GROUP BY l4.user_id) a
                    WHERE NOT a.stss @> '{closed}'::loansstatusenum[]) ui ON ui.user_id = l.user_id
         LEFT JOIN analit_response ar ON ar.user_id = l.user_id
         LEFT JOIN "_successful_calls_Install" sci ON sci.user_id::uuid = l.user_id
WHERE al.user_id IS NULL
  AND bc.user_id IS NULL
  AND ui.user_id IS NULL
  AND sci.user_id IS NULL
  AND (u.user_id <> ALL
       (ARRAY ['e2b3ce5d-560e-4cbe-915f-9578a3f0ec31'::uuid, 'f789a294-1788-4bae-9365-5b9a48447642'::uuid, 'd337032f-e504-47e7-8eae-a0b2a0f8058f'::uuid]))
GROUP BY l.user_id;

alter materialized view mvw_contacts_sale_install owner to "pz-zeppelin";

