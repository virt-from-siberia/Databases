create materialized view mvw_underwriters as
WITH t_work_time AS (
    SELECT DISTINCT liw.loan_id,
                    first_value(adm.username) OVER (PARTITION BY liw.loan_id ORDER BY liw.start_date DESC) AS username,
                    max(liw.start_date) OVER (PARTITION BY liw.loan_id)                                    AS start_date
    FROM loans_in_work liw
             JOIN admins adm USING (admin_id)
             JOIN loans l USING (loan_id)
    WHERE liw.start_date < l.loan_issue_date
       OR l.loan_issue_date IS NULL
),
     t_start AS (
         SELECT sts.loan_id,
                string_agg(sts.comment::text, ' '::text) AS comment,
                max(sts.status_date)                     AS status_date,
                max(sts.subproduct)                      AS subproduct
         FROM (SELECT DISTINCT ON (ls.loan_id, ls.status_name) ls.loan_id,
                                                               ls.comment,
                                                               l2.loan_date_create AS status_date,
                                                               replace(replace(
                                                                               regexp_match(ls.comment::text, '(#\w+)'::text)::text,
                                                                               '{#'::text, ''::text), '}'::text,
                                                                       ''::text)   AS subproduct
               FROM loan_statuses ls
                        JOIN loans l2 ON l2.loan_id = ls.loan_id
               WHERE (ls.status_name = ANY
                      (ARRAY ['setting_a_limit'::loansstatusenum, 'underwriter_refusal'::loansstatusenum, 'loan_approved'::loansstatusenum]))
                 AND ls.is_deleted IS FALSE
               ORDER BY ls.loan_id, ls.status_name, ls.status_date DESC) sts
         GROUP BY sts.loan_id
     ),
     t_solution AS (
         SELECT ls.loan_id,
                max(ls.status_date) AS status_date
         FROM loan_statuses ls
         WHERE (ls.status_name = ANY (ARRAY ['loan_approved'::loansstatusenum, 'underwriter_refusal'::loansstatusenum]))
           AND ls.is_deleted IS FALSE
         GROUP BY ls.loan_id
     ),
     t_status_names AS (
         SELECT DISTINCT ON (ls.loan_id) ls.loan_id,
                                         ls.status_name,
                                         CASE
                                             WHEN ls.status_name = 'closed'::loansstatusenum
                                                 THEN ls.status_date + '03:00:00'::interval
                                             ELSE NULL::timestamp without time zone
                                             END                               AS close_date,
                                         ls.status_date + '03:00:00'::interval AS status_date
         FROM loan_statuses ls
                  JOIN loan_statuses_pk_map ls_pk ON ls_pk.pz_id = ls.status_id
         WHERE ls.is_deleted IS FALSE
         ORDER BY ls.loan_id, ls_pk.sc_id DESC
     ),
     t_loans_score AS (
         SELECT DISTINCT ON (ls.loan_id) ls.loan_id,
                                         replace(replace(regexp_matches(ls.comment::text,
                                                                        'Скоринговый балл ([A-Za-z0-9_]+)'::text,
                                                                        'g'::text)::text, '{'::text, ''::text),
                                                 '}'::text, ''::text)::integer AS scor_saas
         FROM loan_statuses ls
         WHERE ls.comment::text ~~ '%Скоринговый балл%'::text
           AND (ls.status_name = ANY
                (ARRAY ['checking_repeat_client_b'::loansstatusenum, 'checking_new_client_b'::loansstatusenum, 'checking_repeat_client_a'::loansstatusenum, 'checking_new_client_a'::loansstatusenum]))
         ORDER BY ls.loan_id, ls.status_date DESC
     ),
     t_loans_nbki_score AS (
         SELECT DISTINCT ON (l.loan_id) l.loan_id,
                                        COALESCE(npd.score, npd2.score) AS score_nbki
         FROM loans l
                  LEFT JOIN nbki_parsed_data npd ON l.loan_id = npd.loan_id AND npd.score IS NOT NULL
                  LEFT JOIN nbki_parsed_data npd2
                            ON l.user_id = npd2.user_id AND l.loan_date_create > npd2.requested_at AND
                               l.loan_id <> npd2.loan_id AND npd2.score IS NOT NULL
         ORDER BY l.loan_id, npd.requested_at DESC, npd2.requested_at DESC
     ),
     t_last_prolongation AS (
         SELECT DISTINCT t.loan_id,
                         max(t.added_at) OVER (PARTITION BY t.loan_id)                                AS last_prolongation,
                         first_value(t.period)
                         OVER (PARTITION BY t.loan_id ORDER BY t.added_at DESC)                       AS prolongation_period
         FROM loan_prolongations t
     ),
     loans_pay AS (
         SELECT a.loan_id,
                a.amount
         FROM (SELECT tr.loan_id,
                      sum(tr.amount) AS amount
               FROM transactions tr
                        JOIN loans l USING (loan_id)
               WHERE tr.amount > 0::numeric
               GROUP BY tr.loan_id) a
     ),
     agents AS (
         SELECT DISTINCT ON (ls.loan_id) ls.loan_id,
                                         (((adm.last_name::text || ' '::text) || adm.first_name::text) || ' '::text) ||
                                         adm.middle_name::text AS agent_fio,
                                         ash.manager           AS manager_fio,
                                         ash.division          AS agent_group,
                                         ash.region            AS agent_region
         FROM loan_statuses ls
                  JOIN loans l ON l.loan_id = ls.loan_id
                  LEFT JOIN admins adm ON ls.admin_id = adm.admin_id
                  LEFT JOIN _agents_shedule ash ON ash.agent =
                                                   ((((adm.last_name::text || ' '::text) || adm.first_name::text) ||
                                                     ' '::text) || adm.middle_name::text)
         WHERE ls.is_deleted IS FALSE
           AND ls.status_name = 'automatic_check'::loansstatusenum
         ORDER BY ls.loan_id, ls.status_date DESC
     ),
     pti AS (
         SELECT p.loan_id,
                string_agg(((p.pti_value * 100::numeric)::text) || '%'::text, '; '::text) AS pti_valus
         FROM pti_values p
         GROUP BY p.loan_id
     ),
     f AS (
         SELECT l.loan_id,
                count(1)
                FILTER (WHERE sq_max.close_date IS NOT NULL) OVER (PARTITION BY l.user_id ORDER BY l.loan_date_create) AS closed_contracts,
                l.loan_number,
                l.loan_date_create + '03:00:00'::interval                                                              AS loan_date_create,
                l.loan_issue_date + '03:00:00'::interval                                                               AS loan_issue_date,
                p.product_name,
                CASE
                    WHEN t_start.subproduct ~~* '%пилот1%'::text THEN 'Пилот1'::text
                    WHEN t_start.subproduct ~~* '%пилот2%'::text THEN 'Пилот2'::text
                    WHEN t_start.subproduct ~~* '%пилот3%'::text THEN 'Пилот3'::text
                    ELSE t_start.subproduct
                    END                                                                                                AS subproduct,
                lsrc.utm_source,
                CASE
                    WHEN lsrc.utm_source::text ~~ 'C2M%'::text THEN lsrc.utm_content
                    ELSE NULL::character varying
                    END                                                                                                AS utm_content,
                l.loan_sum,
                l.loan_ask_sum,
                CASE
                    WHEN sq_max.status_name::text = 'on_check'::text THEN 'На проверке'::text
                    WHEN sq_max.status_name::text = 'setting_a_limit'::text THEN 'Выставление лимита'::text
                    WHEN sq_max.status_name::text = 'pending_issuance_request'::text THEN 'Ожидание запроса на выдачу'::text
                    WHEN sq_max.status_name::text = 'active_credit'::text THEN 'Активный кредит'::text
                    WHEN sq_max.status_name::text = 'issuance_error'::text THEN 'Ошибка при выдаче'::text
                    WHEN sq_max.status_name::text = 'loan_overdue'::text THEN 'Просрочен'::text
                    WHEN sq_max.status_name::text = 'underwriter_refusal'::text THEN 'Отказ андеррайтера'::text
                    WHEN sq_max.status_name::text = 'failure_automatic'::text THEN 'Отказ автоматический'::text
                    WHEN sq_max.status_name::text = 'client_refusal'::text THEN 'Отказ клиента'::text
                    WHEN sq_max.status_name::text = 'closed'::text THEN 'Закрыт'::text
                    WHEN sq_max.status_name::text = 'closed_overdue'::text THEN 'Закрыт с просрочкой'::text
                    WHEN sq_max.status_name::text = 'frozen_collector'::text THEN 'Заморожен Коллектором'::text
                    WHEN sq_max.status_name::text = 'signing_offer'::text THEN 'Подписание оферты'::text
                    WHEN sq_max.status_name::text = 'loan_approved'::text THEN 'Займ одобрен'::text
                    WHEN sq_max.status_name::text = 'requesting_loan'::text THEN 'Подача заявки на займ'::text
                    WHEN sq_max.status_name::text = 'loan_issued'::text THEN 'Займ выдан'::text
                    WHEN sq_max.status_name::text = 'wrong_form_data'::text THEN 'Заявка заполнена не корректно'::text
                    WHEN sq_max.status_name::text = 'money_transfer'::text THEN 'Перевод денег'::text
                    WHEN sq_max.status_name::text = 'loan_extended'::text THEN 'Займ продлен'::text
                    WHEN sq_max.status_name::text = 'loan_repayment_date'::text THEN 'День погашения займа'::text
                    WHEN sq_max.status_name::text = 'close_or_extend'::text
                        THEN 'Проверка на закрытие или продление займа'::text
                    WHEN sq_max.status_name::text = 'submitted_to_court'::text THEN 'Передано в суд'::text
                    WHEN sq_max.status_name::text = 'automatic_check'::text THEN 'Проверка автоматическая'::text
                    WHEN sq_max.status_name::text = 'period_paid'::text THEN 'Период оплачен'::text
                    WHEN sq_max.status_name::text = 'client_definition'::text THEN 'Определение клиента'::text
                    WHEN sq_max.status_name::text = 'process_definition'::text THEN 'Определение процесса'::text
                    WHEN sq_max.status_name::text = 'checking_new_client_a'::text THEN 'Проверка нового клиента А'::text
                    WHEN sq_max.status_name::text = 'bankrupt'::text THEN 'Банкрот'::text
                    WHEN sq_max.status_name::text = 'checking_repeat_client_a'::text
                        THEN 'Проверка повторного клиента А'::text
                    WHEN sq_max.status_name::text = 'checking_new_client_b'::text THEN 'Проверка нового клиента B'::text
                    WHEN sq_max.status_name::text = 'checking_repeat_client_b'::text
                        THEN 'Проверка повторного клиента B'::text
                    WHEN sq_max.status_name::text = 'ab_test_new'::text THEN 'АБ тест (NEW)'::text
                    WHEN sq_max.status_name::text = 'ab_test_old'::text THEN 'АБ тест (OLD)'::text
                    WHEN sq_max.status_name::text = 'client_died'::text THEN 'Клиент умер'::text
                    WHEN sq_max.status_name::text = 'qiwi_validation'::text THEN 'Идентификация Qiwi'::text
                    WHEN sq_max.status_name::text = 'cession'::text THEN 'Передан по цессии'::text
                    WHEN sq_max.status_name::text = 'checking_new_client'::text THEN 'Проверка нового клиента'::text
                    WHEN sq_max.status_name::text = 'checking_repeat_client'::text THEN 'Проверка повторного клиента'::text
                    WHEN sq_max.status_name::text = 'temp_close'::text THEN 'Предварительно закрыт'::text
                    ELSE sq_max.status_name::text
                    END                                                                                                AS current_status_name,
                sq_max.status_date,
                sq_max.close_date + '03:00:00'::interval                                                               AS close_date,
                CASE
                    WHEN l.is_loan_repeated = true THEN 'Повторная'::text
                    ELSE 'Первичная'::text
                    END                                                                                                AS is_loan_repeated,
                CASE
                    WHEN l.loan_issue_date IS NULL THEN NULL::timestamp without time zone
                    WHEN l.loan_period IS NULL THEN NULL::timestamp without time zone
                    WHEN (p.product_name::text = ANY
                          (ARRAY ['Аннуитет'::character varying, 'Аннуитет 2'::character varying, 'Аннуитет 3'::character varying]::text[])) AND
                         l.loan_period IS NOT NULL AND l.loan_issue_date IS NOT NULL THEN l.loan_issue_date +
                                                                                          concat(l.loan_period * 7, ' days')::interval +
                                                                                          '03:00:00'::interval
                    WHEN (p.product_name::text <> ALL
                          (ARRAY ['Аннуитет'::character varying, 'Аннуитет 2'::character varying, 'Аннуитет 3'::character varying]::text[])) AND
                         l.loan_period IS NOT NULL AND l.loan_issue_date IS NOT NULL THEN l.loan_issue_date +
                                                                                          concat(l.loan_period, ' days')::interval +
                                                                                          '03:00:00'::interval
                    ELSE NULL::timestamp without time zone
                    END                                                                                                AS loan_closed_plan_without_prolongation,
                CASE
                    WHEN l.loan_issue_date IS NULL THEN NULL::date
                    WHEN l.loan_period IS NULL THEN NULL::date
                    WHEN t_last_prolongation.last_prolongation IS NOT NULL THEN (t_last_prolongation.last_prolongation +
                                                                                 '03:00:00'::interval +
                                                                                 concat(t_last_prolongation.prolongation_period, ' days')::interval)::date
                    ELSE (t_last_prolongation.last_prolongation + '03:00:00'::interval +
                          concat(l.loan_period, ' days')::interval)::date
                    END                                                                                                AS loan_closed_plan,
                u.time_zone,
                l.loan_date_create + u.time_zone::interval                                                             AS user_local,
                concat(pd.last_name, ' ', pd.first_name, ' ', pd.middle_name)                                          AS fio,
                phone.number                                                                                           AS phone_number,
                pd.gender,
                date_part('year'::text,
                          age(l.loan_date_create, pd.date_of_birth))                                                   AS age,
                CASE
                    WHEN kladr.region::text ~~* '%алта%респ%'::text THEN 'Республика Алтай'::character varying
                    WHEN kladr.region::text ~~* '%респ%алта%'::text THEN 'Республика Алтай'::character varying
                    WHEN kladr.region::text ~~* '%адыг%'::text THEN 'Республика Адыгея'::character varying
                    WHEN kladr.region::text ~~* '%алтай%кр%'::text THEN 'Алтайский край'::character varying
                    WHEN kladr.region::text ~~* '%алтайск%'::text THEN 'Алтайский край'::character varying
                    WHEN kladr.region::text ~~* '%алтай%'::text THEN 'Республика Алтай'::character varying
                    WHEN kladr.region::text ~~* '%астраханск%'::text THEN 'Астраханская область'::character varying
                    WHEN kladr.region::text ~~* '%амур%'::text THEN 'Амурская область'::character varying
                    WHEN kladr.region::text ~~* '%арханг%'::text THEN 'Архангельская область'::character varying
                    WHEN kladr.region::text ~~* '%байконур%'::text THEN 'Байконур'::character varying
                    WHEN kladr.region::text ~~* '%башк%'::text THEN 'Республика Башкортостан'::character varying
                    WHEN kladr.region::text ~~* '%белгород%'::text THEN 'Белгородская область'::character varying
                    WHEN kladr.region::text ~~* '%брянск%'::text THEN 'Брянская область'::character varying
                    WHEN kladr.region::text ~~* '%бурят%'::text THEN 'Республика Бурятия'::character varying
                    WHEN kladr.region::text ~~* '%владимир%'::text THEN 'Владимировская область'::character varying
                    WHEN kladr.region::text ~~* '%волгоград%'::text THEN 'Волгоградская область'::character varying
                    WHEN kladr.region::text ~~* '%воронеж%'::text THEN 'Воронежская область'::character varying
                    WHEN kladr.region::text ~~* '%вологод%'::text THEN 'Вологодская область'::character varying
                    WHEN kladr.region::text ~~* '%дагест%'::text THEN 'Республика Дагестан'::character varying
                    WHEN kladr.region::text ~~* '%еврей%'::text THEN 'Еврейская автономная область'::character varying
                    WHEN kladr.region::text ~~* '%забайкал%'::text THEN 'Забайкальский край'::character varying
                    WHEN kladr.region::text ~~* '%иркутск%'::text THEN 'Иркутская область'::character varying
                    WHEN kladr.region::text ~~* '%иванов%'::text THEN 'Ивановская область'::character varying
                    WHEN kladr.region::text ~~* '%калинин%'::text THEN 'Калининградская область'::character varying
                    WHEN kladr.region::text ~~* '%калмык%'::text THEN 'Республика Калмыкия'::character varying
                    WHEN kladr.region::text ~~* '%карел%'::text THEN 'Республика Карелия'::character varying
                    WHEN kladr.region::text ~~* '%карачаев%'::text
                        THEN 'Карачаево-Черкесская республика'::character varying
                    WHEN kladr.region::text ~~* '%калу%'::text THEN 'Калужская область'::character varying
                    WHEN kladr.region::text ~~* '%камчат%'::text THEN 'Камчатский край'::character varying
                    WHEN kladr.region::text ~~* '%кабардин%'::text
                        THEN 'Кабардино-Балкарская республика'::character varying
                    WHEN kladr.region::text ~~* '%кемеро%'::text THEN 'Кемеровская область'::character varying
                    WHEN kladr.region::text ~~* '%кировск%'::text THEN 'Кировская область'::character varying
                    WHEN kladr.region::text ~~* '%костром%'::text THEN 'Костромская область'::character varying
                    WHEN kladr.region::text ~~* '%коми%'::text THEN 'Республика Коми'::character varying
                    WHEN kladr.region::text ~~* '%краснодар%'::text THEN 'Краснодарский край'::character varying
                    WHEN kladr.region::text ~~* '%красноярск%'::text THEN 'Красноярский край'::character varying
                    WHEN kladr.region::text ~~* '%крым%'::text THEN 'Республика Крым'::character varying
                    WHEN kladr.region::text ~~* '%курган%'::text THEN 'Курганская область'::character varying
                    WHEN kladr.region::text ~~* '%курск%'::text THEN 'Курская область'::character varying
                    WHEN kladr.region::text ~~* '%ленинград%'::text THEN 'Ленинградская область'::character varying
                    WHEN kladr.region::text ~~* '%липец%'::text THEN 'Липецкая область'::character varying
                    WHEN kladr.region::text ~~* '%мар%эл%'::text THEN 'Республика Марий Эл'::character varying
                    WHEN kladr.region::text ~~* '%магад%'::text THEN 'Магаданская область'::character varying
                    WHEN kladr.region::text ~~* '%москва%'::text THEN 'Москва'::character varying
                    WHEN kladr.region::text ~~* '%москов%'::text THEN 'Московская область'::character varying
                    WHEN kladr.region::text ~~* '%мордо%'::text THEN 'Республика Мордовия'::character varying
                    WHEN kladr.region::text ~~* '%мурман%'::text THEN 'Мурманская область'::character varying
                    WHEN kladr.region::text ~~* '%новосиб%'::text THEN 'Новосибирская область'::character varying
                    WHEN kladr.region::text ~~* '%нижегор%'::text THEN 'Нижегородская область'::character varying
                    WHEN kladr.region::text ~~* '%новгор%'::text THEN 'Новгородская область'::character varying
                    WHEN kladr.region::text ~~* '%омск%'::text THEN 'Омская область'::character varying
                    WHEN kladr.region::text ~~* '%оренбург%'::text THEN 'Оренбургская область'::character varying
                    WHEN kladr.region::text ~~* '%орлов%'::text THEN 'Орловская область'::character varying
                    WHEN kladr.region::text ~~* '%перм%'::text THEN 'Пермсий край'::character varying
                    WHEN kladr.region::text ~~* '%пенз%'::text THEN 'Пензенская область'::character varying
                    WHEN kladr.region::text ~~* '%примор%'::text THEN 'Приморский край'::character varying
                    WHEN kladr.region::text ~~* '%псков%'::text THEN 'Псковская область'::character varying
                    WHEN kladr.region::text ~~* '%ростов%'::text THEN 'Ростовская область'::character varying
                    WHEN kladr.region::text ~~* '%рязан%'::text THEN 'Рязанская область'::character varying
                    WHEN kladr.region::text ~~* '%самарс%'::text THEN 'Самарская область'::character varying
                    WHEN kladr.region::text ~~* '%санкт%'::text THEN 'Санкт-Петербург'::character varying
                    WHEN kladr.region::text ~~* '%саратов%'::text THEN 'Саратовская область'::character varying
                    WHEN kladr.region::text ~~* '%самар%'::text THEN 'Самарская область'::character varying
                    WHEN kladr.region::text ~~* '%сахал%'::text THEN 'Сахалинская область'::character varying
                    WHEN kladr.region::text ~~* '%осети%'::text THEN 'Республика Северная Осетия'::character varying
                    WHEN kladr.region::text ~~* '%свердл%'::text THEN 'Свердловская область'::character varying
                    WHEN kladr.region::text ~~* '%смоленс%'::text THEN 'Смоленская область'::character varying
                    WHEN kladr.region::text ~~* '%ставроп%'::text THEN 'Ставропольский край'::character varying
                    WHEN kladr.region::text ~~* '%тамб%'::text THEN 'Тамбовская область'::character varying
                    WHEN kladr.region::text ~~* '%татар%'::text THEN 'Республика Татарстан'::character varying
                    WHEN kladr.region::text ~~* '%тверск%'::text THEN 'Тверская область'::character varying
                    WHEN kladr.region::text ~~* '%томск%'::text THEN 'Томская область'::character varying
                    WHEN kladr.region::text ~~* '%тульс%'::text THEN 'Тульская область'::character varying
                    WHEN kladr.region::text ~~* '%тюменс%'::text THEN 'Тюменская область'::character varying
                    WHEN kladr.region::text ~~* '%ульян%'::text THEN 'Ульяновская область'::character varying
                    WHEN kladr.region::text ~~* '%удмур%'::text THEN 'Республика Удмуртия'::character varying
                    WHEN kladr.region::text ~~* '%хабар%'::text THEN 'Хабаровский край'::character varying
                    WHEN kladr.region::text ~~* '%хакас%'::text THEN 'Республика Хакасия'::character varying
                    WHEN kladr.region::text ~~* '%ханты%'::text
                        THEN 'Ханты-Мансийский автономный округ'::character varying
                    WHEN kladr.region::text ~~* '%хмао%'::text
                        THEN 'Ханты-Мансийский автономный округ'::character varying
                    WHEN kladr.region::text ~~* '%челябин%'::text THEN 'Челябинская область'::character varying
                    WHEN kladr.region::text ~~* '%чечен%'::text THEN 'Республика Чечня'::character varying
                    WHEN kladr.region::text ~~* '%чуваш%'::text THEN 'Республика Чувашия'::character varying
                    WHEN kladr.region::text ~~* '%ямало%'::text
                        THEN 'Ямало-Ненецкий автономный округ'::character varying
                    WHEN kladr.region::text ~~* '%янао%'::text THEN 'Ямало-Ненецкий автономный округ'::character varying
                    WHEN kladr.region::text ~~* '%респ%саха%'::text THEN 'Республика Саха (Якутия)'::character varying
                    WHEN kladr.region::text ~~* '%якут%'::text THEN 'Республика Саха (Якутия)'::character varying
                    WHEN kladr.region::text ~~* '%якут%'::text THEN 'Республика Саха (Якутия)'::character varying
                    WHEN kladr.region::text ~~* '%яросл%'::text THEN 'Ярославская область'::character varying
                    WHEN kladr.region::text ~~* '%тыва%'::text THEN 'Республика Тыва'::character varying
                    ELSE kladr.region
                    END                                                                                                AS region,
                kladr.city,
                pti.pti_valus,
                t_loans_score.scor_saas                                                                                AS scoring_score,
                t_loans_nbki_score.score_nbki,
                (sr.score * 100::numeric) || '%'::text                                                                 AS scor_ruszaim,
                t_work_time.username                                                                                   AS underwriter_name,
                t_start.comment,
                CASE
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND t_start.comment ~~* '%скор%'::text
                        THEN 'Скорр балл'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND t_start.comment ~~* '%негатив%'::text
                        THEN 'Негатив'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         t_start.comment ~~* '%закредит%'::text THEN 'Закредитовка'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND t_start.comment ~~* '%бки%'::text
                        THEN 'НБКИ Нет информации'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         (t_start.comment ~~* '%серия%номер%'::text OR t_start.comment ~~* '%номер%пасп% не%'::text OR
                          t_start.comment ~~* '%сер%пасп% не%'::text) THEN 'Номер/серия'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         (t_start.comment ~~* '%регистрац%'::text OR t_start.comment ~~* '%прописк%'::text)
                        THEN 'Регистрация'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND t_start.comment ~~* '%инн%'::text
                        THEN 'Нет ИНН'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         (t_start.comment ~~* '%фото%'::text OR t_start.comment ~~* '%паспорт%'::text OR
                          t_start.comment ~~* '%документ%'::text OR t_start.comment ~~* '%регистрац%'::text)
                        THEN 'Документы'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND t_start.comment ~~* '%карт%'::text
                        THEN 'Карта'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         (t_start.comment ~~* '%сфер%'::text OR t_start.comment ~~* '%гос%месседж%'::text) THEN 'Сфера'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         t_start.comment ~~* '%день%в%день%'::text THEN 'Закрывается день в день'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND t_start.comment ~~* '%мутный%'::text
                        THEN 'Мутный клиент'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         (t_start.comment ~~* '%регион%'::text OR t_start.comment ~~* '%рег% сим%'::text OR
                          t_start.comment ~~* '%симки%'::text OR t_start.comment ~~ '%СИМ%'::text) THEN 'Регион СИМ'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         t_start.comment ~~* '%нет конт%'::text THEN 'Нет контакта'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum AND
                         (t_start.comment ~~* '%самоотказ%'::text OR t_start.comment ~~* '%отказался%'::text OR
                          t_start.comment ~~* '%отказ%клиент%'::text OR t_start.comment ~~* '%отказ%займ%'::text OR
                          t_start.comment ~~* '%отказ%заявк%'::text) THEN 'Самоотказ'::text
                    WHEN sq_max.status_name = 'underwriter_refusal'::loansstatusenum THEN 'Другое'::text
                    ELSE NULL::text
                    END                                                                                                AS good_comment,
                t_start.status_date + '03:00:00'::interval                                                             AS start_date,
                t_work_time.start_date + '03:00:00'::interval                                                          AS in_work_date,
                t_solution.status_date + '03:00:00'::interval                                                          AS solution_date,
                loans_pay.amount,
                ag.agent_fio,
                ag.agent_group,
                ag.agent_region
         FROM loans l
                  JOIN users u ON l.user_id = u.user_id AND u.time_zone IS NOT NULL AND u.time_zone::text <> '+14:87'::text
                  JOIN t_status_names sq_max USING (loan_id)
                  JOIN products p USING (product_id)
                  LEFT JOIN passport pd ON l.user_id = pd.user_id
                  LEFT JOIN t_work_time USING (loan_id)
                  LEFT JOIN t_start USING (loan_id)
                  LEFT JOIN t_solution USING (loan_id)
                  LEFT JOIN phone_numbers phone ON phone.user_id = u.user_id AND phone.is_default = true
                  LEFT JOIN kladr ON kladr.id = pd.actual_address_id
                  LEFT JOIN t_loans_score USING (loan_id)
                  LEFT JOIN t_loans_nbki_score USING (loan_id)
                  LEFT JOIN t_last_prolongation USING (loan_id)
                  LEFT JOIN loan_source lsrc USING (loan_id)
                  LEFT JOIN loans_pay USING (loan_id)
                  LEFT JOIN scoring_results sr USING (loan_id)
                  LEFT JOIN agents ag USING (loan_id)
                  LEFT JOIN pti USING (loan_id)
     )
SELECT f.loan_number,
       f.closed_contracts,
       to_char(f.loan_date_create, 'DD-MM-YYYY'::text)                           AS loan_date_create_date,
       to_char(f.loan_date_create, 'HH24:MI:SS'::text)                           AS loan_date_create_time,
       to_char(f.loan_issue_date, 'DD-MM-YYYY'::text)                            AS loan_issue_date_date,
       f.product_name,
       f.subproduct,
       f.utm_source,
       f.utm_content,
       f.loan_sum,
       f.loan_ask_sum,
       f.current_status_name,
       f.status_date,
       f.is_loan_repeated,
       to_char(f.loan_closed_plan::timestamp with time zone, 'DD-MM-YYYY'::text) AS loan_closed_plan,
       to_char(f.loan_closed_plan_without_prolongation, 'DD-MM-YYYY'::text)      AS loan_closed_plan_without_prolongation,
       to_char(f.close_date, 'DD-MM-YYYY'::text)                                 AS close_date,
       f.time_zone,
       to_char(f.user_local, 'DD-MM-YYYY'::text)                                 AS user_local_date,
       to_char(f.user_local, 'HH24:MI:SS'::text)                                 AS user_local_time,
       f.fio,
       f.phone_number,
       f.gender,
       f.age,
       f.region,
       f.city,
       f.pti_valus,
       f.scoring_score,
       f.score_nbki,
       f.scor_ruszaim,
       f.underwriter_name,
       f.comment,
       f.good_comment,
       f.start_date,
       f.in_work_date,
       f.solution_date,
       to_char(
               CASE
                   WHEN f.in_work_date >= f.start_date AND f.in_work_date <= f.solution_date
                       THEN f.in_work_date - f.start_date
                   ELSE NULL::interval
                   END, 'DD HH24:MI:SS'::text)                                   AS interval1,
       to_char(
               CASE
                   WHEN f.in_work_date >= f.start_date AND f.in_work_date <= f.solution_date
                       THEN f.solution_date - f.in_work_date
                   ELSE NULL::interval
                   END, 'DD HH24:MI:SS'::text)                                   AS interval2,
       to_char(f.solution_date - f.start_date, 'DD HH24:MI:SS'::text)            AS interval3,
       CASE
           WHEN date_part('hour'::text, f.loan_date_create) >= 7::double precision AND
                date_part('hour'::text, f.loan_date_create) < 19::double precision THEN 'day'::text
           ELSE 'night'::text
           END                                                                   AS day_night,
       f.amount,
       f.agent_fio,
       f.agent_group,
       f.agent_region
FROM f
WHERE f.loan_date_create >= '2020-08-01 00:00:00'::timestamp without time zone;

alter materialized view mvw_underwriters owner to "pz-zeppelin";

