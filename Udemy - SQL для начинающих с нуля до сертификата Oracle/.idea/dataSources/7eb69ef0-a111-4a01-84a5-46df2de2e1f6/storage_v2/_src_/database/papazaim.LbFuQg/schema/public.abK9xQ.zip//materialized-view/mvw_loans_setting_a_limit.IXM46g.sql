create materialized view mvw_loans_setting_a_limit as
SELECT DISTINCT ON (loans.loan_id) loans.loan_id                                      AS loans_loan_id,
                                   admins.username                                    AS admin_username,
                                   (SELECT count(1) AS count
                                    FROM loan_comments
                                    WHERE loan_comments.user_id = loans.user_id)      AS comments_count,
                                   loan_statuses.accept                               AS loan_statuses_accept,
                                   loan_statuses.comment                              AS loan_statuses_comment,
                                   loan_statuses.is_deleted                           AS loan_statuses_is_deleted,
                                   loan_statuses.status_date                          AS loan_statuses_status_date,
                                   loan_statuses.status_id                            AS loan_statuses_status_id,
                                   loan_statuses.status_name                          AS loan_statuses_status_name,
                                   loans.credit_rate                                  AS loans_credit_rate,
                                   loans.is_loan_repeated                             AS loans_is_loan_repeated,
                                   loans.is_request_repeated                          AS loans_is_request_repeated,
                                   loans.loan_ask_period                              AS loans_loan_ask_period,
                                   loans.loan_ask_sum                                 AS loans_loan_ask_sum,
                                   loans.loan_date_create                             AS loans_loan_date_create,
                                   loans.loan_issue_date                              AS loans_loan_issue_date,
                                   loans.loan_number                                  AS loans_loan_number,
                                   loans.loan_period                                  AS loans_loan_period,
                                   loans.loan_permitted_period                        AS loans_loan_permitted_period,
                                   loans.loan_permitted_sum                           AS loans_loan_permitted_sum,
                                   loans.loan_sum                                     AS loans_loan_sum,
                                   loans.product_id                                   AS loans_product_id,
                                   loans.saas_uid                                     AS loans_saas_uid,
                                   loans.selected_loan_period                         AS loans_selected_loan_period,
                                   loans_in_work.admin_id                             AS loans_in_work_admin_id,
                                   loans_in_work.is_revoked                           AS loans_in_work_is_revoked,
                                   loans_in_work.start_date                           AS loans_in_work_start_date,
                                   loans_in_work.stop_date                            AS loans_in_work_stop_date,
                                   loans_in_work.work_id                              AS loans_in_work_work_id,
                                   passport.actual_address_id                         AS passport_actual_address_id,
                                   passport.code_division                             AS passport_code_division,
                                   passport.date_of_birth                             AS passport_date_of_birth,
                                   passport.date_of_issue                             AS passport_date_of_issue,
                                   passport.first_name                                AS passport_first_name,
                                   passport.gender                                    AS passport_gender,
                                   passport.id                                        AS passport_id,
                                   passport.last_name                                 AS passport_last_name,
                                   passport.middle_name                               AS passport_middle_name,
                                   passport.number                                    AS passport_number,
                                   passport.place_of_birth                            AS passport_place_of_birth,
                                   passport.place_of_issue                            AS passport_place_of_issue,
                                   passport.registration_address_id                   AS passport_registration_address_id,
                                   passport.serial                                    AS passport_serial,
                                   kladr.city                                         AS registration_address,
                                   (SELECT count(1) AS requests_count
                                    FROM loans lc
                                    WHERE lc.user_id = loans.user_id)                 AS requests_count,
                                   actual_kladr.region                                AS residence_address,
                                   users.check_word                                   AS users_check_word,
                                   users.children_amount                              AS users_children_amount,
                                   users.date_register                                AS users_date_register,
                                   users.email                                        AS users_email,
                                   users.login                                        AS users_login,
                                   users.maiden_name                                  AS users_maiden_name,
                                   users.marital_status                               AS users_marital_status,
                                   users.time_zone                                    AS users_time_zone,
                                   users.user_id                                      AS users_user_id,
                                   loan_source.utm_source,
                                   (SELECT count(1) AS closed_count
                                    FROM loans l
                                             JOIN loan_statuses ls ON l.loan_id = ls.loan_id
                                    WHERE l.user_id = loans.user_id
                                      AND ls.status_name = 'closed'::loansstatusenum) AS closed_count
FROM last_loan_status
         JOIN loan_statuses
              ON loan_statuses.status_id = last_loan_status.status_id AND loan_statuses.status_name = 'setting_a_limit'::loansstatusenum
         JOIN loans ON loans.loan_id = last_loan_status.loan_id
         JOIN users ON users.user_id = loans.user_id
         JOIN passport ON passport.user_id = loans.user_id
         LEFT JOIN loans_in_work ON loans_in_work.loan_id = loans.loan_id AND loans_in_work.is_revoked IS FALSE
         LEFT JOIN admins ON admins.admin_id = loans_in_work.admin_id
         LEFT JOIN kladr ON passport.registration_address_id = kladr.id
         LEFT JOIN kladr actual_kladr ON passport.actual_address_id = actual_kladr.id
         LEFT JOIN loan_source ON loans.loan_id = loan_source.loan_id;

alter materialized view mvw_loans_setting_a_limit owner to "pz-crm-user";

create unique index uix_mvw_loans_setting_a_limit
    on mvw_loans_setting_a_limit (loans_loan_id);

