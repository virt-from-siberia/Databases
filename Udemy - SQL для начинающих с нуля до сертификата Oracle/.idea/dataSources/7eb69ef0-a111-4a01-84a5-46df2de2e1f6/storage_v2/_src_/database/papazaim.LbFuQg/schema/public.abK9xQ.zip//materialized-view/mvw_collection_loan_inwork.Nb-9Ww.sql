create materialized view mvw_collection_loan_inwork as
WITH collect_loan_in_work AS (
    SELECT cs.loan_id,
           (cs.created_at + '03:00:00'::interval)::date AS dt_from,
           a.username,
           cs.comment,
           CASE
               WHEN ((cs.created_at + '03:00:00'::interval)::date + 35) >
                    lead((cs.created_at + '03:00:00'::interval)::date)
                    OVER (PARTITION BY cs.loan_id ORDER BY cs.created_at) THEN lead(
                                                                               (cs.created_at + '03:00:00'::interval)::date)
                                                                               OVER (PARTITION BY cs.loan_id ORDER BY cs.created_at)
               ELSE (cs.created_at + '03:00:00'::interval)::date + 35
               END                                      AS dt_before
    FROM collector_tasks cs
             JOIN admins a ON a.admin_id = cs.admin_id
    WHERE cs.task_status = 'receptive'::collectortasksstatusenum
      AND a.username::text <> 'd.parshenkov'::text
    ORDER BY cs.created_at
)
SELECT mlb.check_dt,
       mlb.loan_id,
       l.loan_number,
       mlb.status_name,
       cliw.username,
       cliw.dt_from,
       cliw.comment,
       mlb.principal_debt,
       mlb.interest_debt,
       mlb.service_debt,
       (((p.last_name::text || ' '::text) || p.first_name::text) || ' '::text) || p.middle_name::text AS fio,
       u.time_zone,
       pn.number                                                                                      AS phone
FROM mvw_loan_balances mlb
         JOIN loans l ON l.loan_id = mlb.loan_id
         JOIN users u ON u.user_id = l.user_id
         JOIN passport p ON p.user_id = l.user_id
         LEFT JOIN phone_numbers pn ON pn.user_id = l.user_id AND pn.is_default IS TRUE AND pn.is_active IS TRUE
         LEFT JOIN collect_loan_in_work cliw
                   ON cliw.loan_id = mlb.loan_id AND mlb.check_dt >= cliw.dt_from AND mlb.check_dt < cliw.dt_before AND
                      mlb.status_name = 'loan_overdue'::loansstatusenum;

alter materialized view mvw_collection_loan_inwork owner to "pz-zeppelin";

