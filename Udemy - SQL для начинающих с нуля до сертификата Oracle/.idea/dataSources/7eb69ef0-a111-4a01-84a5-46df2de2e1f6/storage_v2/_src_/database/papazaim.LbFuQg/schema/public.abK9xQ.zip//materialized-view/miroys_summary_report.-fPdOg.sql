create materialized view miroys_summary_report as
WITH t_days_overdue AS (
    SELECT t.loan_id,
           sum(t.delay) AS days_delay
    FROM (SELECT ls.loan_id,
                 ls.status_name,
                 ls.status_date,
                 1 + COALESCE(lead(ls.status_date)
                              OVER (PARTITION BY ls.loan_id ORDER BY ls.status_date)::timestamp with time zone,
                              now())::date - ls.status_date::date - 1 AS delay
          FROM loan_statuses ls) t
    WHERE t.status_name = 'loan_overdue'::loansstatusenum
    GROUP BY t.loan_id
),
     t_transactions_sum AS (
         SELECT t.loan_id,
                sum(t.amount)    AS sum_profit,
                sum(
                        CASE
                            WHEN t.trans_type = ANY
                                 (ARRAY ['auto_debit'::transtypeenum, 'loan_repayment'::transtypeenum]) THEN t.amount
                            ELSE NULL::numeric
                            END) AS sum_repayment,
                count(
                        CASE
                            WHEN t.trans_type = 'loan_prolongation'::transtypeenum THEN t.amount
                            ELSE NULL::numeric
                            END) AS cnt_prolongation,
                sum(
                        CASE
                            WHEN t.trans_type = 'loan_prolongation'::transtypeenum THEN t.amount
                            ELSE NULL::numeric
                            END) AS sum_prolongation,
                sum(
                        CASE
                            WHEN t.trans_type = 'payment_for_service'::transtypeenum THEN t.amount
                            ELSE NULL::numeric
                            END) AS sum_service,
                max(
                        CASE
                            WHEN t.trans_type = 'loan_prolongation'::transtypeenum THEN t.trans_date + '03:00:00'::interval
                            ELSE NULL::timestamp without time zone
                            END) AS last_prolongation
         FROM transactions t
         GROUP BY t.loan_id
     ),
     f AS (
         SELECT l.loan_id,
                l.loan_number,
                (l.loan_issue_date + '03:00:00'::interval)::date                    AS loan_issue_date,
                (l.loan_date_create + '03:00:00'::interval)::date                   AS loan_date_create,
                to_char(l.loan_date_create + '03:00:00'::interval, 'yyyy-mm'::text) AS loan_date_create_month,
                to_char(l.loan_date_create + '03:00:00'::interval, 'yyyy-ww'::text) AS loan_date_create_week,
                current_status.status_name,
                CASE
                    WHEN current_status.status_name = 'closed'::loansstatusenum THEN 1
                    ELSE NULL::integer
                    END                                                             AS loan_closed,
                CASE
                    WHEN current_status.status_name = ANY
                         (ARRAY ['bankrupt'::loansstatusenum, 'client_died'::loansstatusenum]) THEN 1
                    ELSE NULL::integer
                    END                                                             AS loan_bankrupt,
                CASE
                    WHEN current_status.status_name = 'cession'::loansstatusenum THEN 1
                    ELSE NULL::integer
                    END                                                             AS loan_cession,
                CASE
                    WHEN l.loan_issue_date IS NOT NULL AND l.loan_period IS NOT NULL AND
                         (l.loan_issue_date + '03:00:00'::interval +
                          concat(l.selected_loan_period, ' days')::interval) < now() THEN 1
                    ELSE NULL::integer
                    END                                                             AS loan_aging,
                lsrc.utm_source,
                lsrc.utm_content,
                l.loan_sum,
                l.selected_loan_period                                              AS loan_period_days,
                t_days_overdue.days_delay,
                CASE
                    WHEN current_status.status_name = 'loan_overdue'::loansstatusenum AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) >=
                         1::double precision AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) <
                         10::double precision THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_current_1,
                CASE
                    WHEN current_status.status_name = 'loan_overdue'::loansstatusenum AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) >=
                         10::double precision AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) <
                         20::double precision THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_current_10,
                CASE
                    WHEN current_status.status_name = 'loan_overdue'::loansstatusenum AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) >=
                         20::double precision AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) <
                         30::double precision THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_current_20,
                CASE
                    WHEN current_status.status_name = 'loan_overdue'::loansstatusenum AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) >=
                         30::double precision AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) <
                         45::double precision THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_current_30,
                CASE
                    WHEN current_status.status_name = 'loan_overdue'::loansstatusenum AND
                         date_part('day'::text, now() - current_status.status_date::timestamp with time zone) >=
                         45::double precision THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_current_45,
                CASE
                    WHEN t_days_overdue.days_delay >= 1 AND t_days_overdue.days_delay < 10 THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_1,
                CASE
                    WHEN t_days_overdue.days_delay >= 10 AND t_days_overdue.days_delay < 20 THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_10,
                CASE
                    WHEN t_days_overdue.days_delay >= 20 AND t_days_overdue.days_delay < 30 THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_20,
                CASE
                    WHEN t_days_overdue.days_delay >= 30 AND t_days_overdue.days_delay < 45 THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_30,
                CASE
                    WHEN t_days_overdue.days_delay >= 45 THEN 1
                    ELSE NULL::integer
                    END                                                             AS npl_45,
                CASE
                    WHEN l.is_loan_repeated = true THEN 'Повторная'::text
                    ELSE 'Первичная'::text
                    END                                                             AS is_loan_repeated,
                l.user_id,
                t_transactions_sum.sum_repayment,
                CASE
                    WHEN t_transactions_sum.sum_service > 0::numeric THEN 1
                    ELSE NULL::integer
                    END                                                             AS flg_service_pay,
                t_transactions_sum.sum_service,
                t_transactions_sum.cnt_prolongation,
                CASE
                    WHEN t_transactions_sum.cnt_prolongation > 0 THEN 1
                    ELSE NULL::integer
                    END                                                             AS flg_prolongation,
                t_transactions_sum.sum_prolongation,
                CASE
                    WHEN current_status.status_name = 'cession'::loansstatusenum OR
                         current_status.status_name = 'loan_overdue'::loansstatusenum AND t_days_overdue.days_delay > 45
                        THEN (- l.loan_sum) + l.loan_sum * 2.5 * 0.2
                    WHEN current_status.status_name = 'issuance_error'::loansstatusenum THEN 0::numeric
                    WHEN current_status.status_name = ANY
                         (ARRAY ['bankrupt'::loansstatusenum, 'client_died'::loansstatusenum])
                        THEN t_transactions_sum.sum_profit
                    ELSE t_transactions_sum.sum_profit
                    END                                                             AS sum_profit
         FROM loans l
                  LEFT JOIN last_loan_status USING (loan_id)
                  LEFT JOIN loan_statuses current_status USING (loan_id, status_id)
                  LEFT JOIN t_days_overdue USING (loan_id)
                  LEFT JOIN t_transactions_sum USING (loan_id)
                  LEFT JOIN loan_source lsrc USING (loan_id)
         WHERE 1 = 1
           AND (l.product_id = ANY
                (ARRAY ['6040e8d9-68d0-4466-a921-6864dbe592f3'::uuid, '2e5b6e3b-c702-4a30-8429-1cf62fdc1e52'::uuid, '9096b038-4948-40a0-b1e9-71190da96647'::uuid]))
     ),
     t_clients_first_loan AS (
         SELECT ll.user_id,
                min(ll.loan_date_create) + '03:00:00'::interval AS first_loan_date
         FROM loans ll
         WHERE ll.loan_sum IS NOT NULL
           AND ll.is_loan_repeated IS FALSE
         GROUP BY ll.user_id
     ),
     t_clients_ltv_90_loan AS (
         SELECT f_1.user_id,
                sum(
                        CASE
                            WHEN f_1.loan_sum IS NOT NULL THEN 1
                            ELSE NULL::integer
                            END)    AS client_cnt_loans_90,
                sum(f_1.sum_profit) AS client_sum_profit_90
         FROM f f_1
                  LEFT JOIN t_clients_first_loan USING (user_id)
         WHERE f_1.loan_sum IS NOT NULL
           AND f_1.is_loan_repeated = 'Повторная'::text
           AND f_1.loan_date_create <= (t_clients_first_loan.first_loan_date + '90 days'::interval)
         GROUP BY f_1.user_id
     ),
     t_clients_ltv_180_loan AS (
         SELECT f_1.user_id,
                sum(
                        CASE
                            WHEN f_1.loan_sum IS NOT NULL THEN 1
                            ELSE NULL::integer
                            END)    AS client_cnt_loans_180,
                sum(f_1.sum_profit) AS client_sum_profit_180
         FROM f f_1
                  LEFT JOIN t_clients_first_loan USING (user_id)
         WHERE f_1.loan_sum IS NOT NULL
           AND f_1.is_loan_repeated = 'Повторная'::text
           AND f_1.loan_date_create <= (t_clients_first_loan.first_loan_date + '180 days'::interval)
         GROUP BY f_1.user_id
     )
SELECT f.loan_id,
       f.loan_number,
       f.loan_issue_date,
       f.loan_date_create,
       f.loan_date_create_month,
       f.loan_date_create_week,
       f.status_name,
       f.loan_closed,
       f.loan_bankrupt,
       f.loan_cession,
       f.loan_aging,
       f.utm_source,
       f.utm_content,
       f.loan_sum,
       f.loan_period_days,
       f.days_delay,
       f.npl_current_1,
       f.npl_current_10,
       f.npl_current_20,
       f.npl_current_30,
       f.npl_current_45,
       f.npl_1,
       f.npl_10,
       f.npl_20,
       f.npl_30,
       f.npl_45,
       f.is_loan_repeated,
       f.user_id,
       f.sum_repayment,
       f.flg_service_pay,
       f.sum_service,
       f.cnt_prolongation,
       f.flg_prolongation,
       f.sum_prolongation,
       f.sum_profit,
       CASE
           WHEN t_clients_ltv_90_loan.client_cnt_loans_90 IS NOT NULL THEN t_clients_ltv_90_loan.client_cnt_loans_90
           ELSE 0::bigint
           END AS client_cnt_loans_90,
       CASE
           WHEN f.is_loan_repeated = 'Первичная'::text AND t_clients_ltv_180_loan.client_cnt_loans_180 > 0
               THEN t_clients_ltv_180_loan.client_cnt_loans_180
           ELSE NULL::bigint
           END AS client_cnt_loans_180
FROM f
         LEFT JOIN t_clients_ltv_90_loan USING (user_id)
         LEFT JOIN t_clients_ltv_180_loan USING (user_id);

alter materialized view miroys_summary_report owner to "pz-zeppelin";

