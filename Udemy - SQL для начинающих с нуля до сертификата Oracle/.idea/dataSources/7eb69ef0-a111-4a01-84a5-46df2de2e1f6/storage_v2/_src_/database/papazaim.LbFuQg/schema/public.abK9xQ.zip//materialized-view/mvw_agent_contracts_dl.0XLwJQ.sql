create materialized view mvw_agent_contracts_dl as
WITH stage_1 AS (
    SELECT mac.start_bw,
           mac.stop_bw,
           mac.num,
           mac.loan_id,
           mac.region,
           mac."group",
           mac.manager_fio,
           mac.agent_fio,
           mac.loan_number,
           mac.fio,
           mac.reg_adress,
           mac.fact_adress,
           mac.number,
           mac.company_name,
           mac.friends,
           mac.product_name,
           mac.loan_num_bw,
           mac.open_dt,
           mac.loan_sum,
           mac.plan_pay,
           mac.plan_pay_week,
           mac.balance,
           mac.pay_made,
           mac.status_name,
           mac.principal_debt,
           mac.total_debt,
           mac.pay_all_cum,
           mac.repaid_interest,
           mac.cumulat_principal,
           mac.current_overdue,
           mac.flg_overdue,
           mac.week_overdue,
           mac.cum_overdue,
           mac.pay_partial,
           mac.pay_full,
           mac.early_repayment_dt,
           mac.client_type,
           CASE
               WHEN mac.client_type = 'Первичный'::text AND mac.loan_num_bw = 0 THEN 3000
               WHEN mac.client_type = 'Повторный'::text AND mac.loan_num_bw = 0 THEN 1000
               ELSE NULL::integer
               END                                                                 AS award_issuance,
           COALESCE(mac.pay_made, 0::numeric) - COALESCE(mac.pay_full, 0::numeric) AS net_pay,
           sum((COALESCE(mac.pay_made, 0::numeric) - COALESCE(mac.pay_full, 0::numeric)) / mac.plan_pay_week)
           OVER (PARTITION BY mac.loan_number ORDER BY mac.start_bw)               AS payments_cum,
           CASE
               WHEN count(1)
                    FILTER (WHERE COALESCE(mac.week_overdue, 0::bigint) <= 6) OVER (PARTITION BY mac.agent_fio, mac.start_bw) =
                    0 THEN 0::double precision
               ELSE 1::double precision - count(1)
                                          FILTER (WHERE mac.week_overdue <= 6) OVER (PARTITION BY mac.agent_fio, mac.start_bw)::double precision /
                                          count(1)
                                          FILTER (WHERE COALESCE(mac.week_overdue, 0::bigint) <= 6) OVER (PARTITION BY mac.agent_fio, mac.start_bw)::double precision
               END                                                                 AS effectiv_ind
    FROM mvw_agent_contracts mac
),
     stage_2 AS (
         SELECT stage_1.start_bw,
                stage_1.stop_bw,
                stage_1.num,
                stage_1.loan_id,
                stage_1.region,
                stage_1."group",
                stage_1.manager_fio,
                stage_1.agent_fio,
                stage_1.loan_number,
                stage_1.fio,
                stage_1.reg_adress,
                stage_1.fact_adress,
                stage_1.number,
                stage_1.company_name,
                stage_1.friends,
                stage_1.product_name,
                stage_1.loan_num_bw,
                stage_1.open_dt,
                stage_1.loan_sum,
                stage_1.plan_pay,
                stage_1.plan_pay_week,
                stage_1.balance,
                stage_1.pay_made,
                stage_1.status_name,
                stage_1.principal_debt,
                stage_1.total_debt,
                stage_1.pay_all_cum,
                stage_1.repaid_interest,
                stage_1.cumulat_principal,
                stage_1.current_overdue,
                stage_1.flg_overdue,
                stage_1.week_overdue,
                stage_1.cum_overdue,
                stage_1.pay_partial,
                stage_1.pay_full,
                stage_1.early_repayment_dt,
                stage_1.client_type,
                stage_1.award_issuance,
                stage_1.net_pay,
                stage_1.payments_cum,
                stage_1.effectiv_ind,
                CASE
                    WHEN stage_1.effectiv_ind < 0.6::double precision THEN 0.2
                    WHEN stage_1.effectiv_ind >= 0.6::double precision AND stage_1.effectiv_ind < 0.65::double precision
                        THEN 0.4
                    WHEN stage_1.effectiv_ind >= 0.65::double precision AND stage_1.effectiv_ind < 0.7::double precision
                        THEN 0.5
                    WHEN stage_1.effectiv_ind >= 0.7::double precision AND stage_1.effectiv_ind < 0.75::double precision
                        THEN 0.6
                    WHEN stage_1.effectiv_ind >= 0.75::double precision AND stage_1.effectiv_ind < 0.8::double precision
                        THEN 0.8
                    WHEN stage_1.effectiv_ind >= 0.8::double precision AND stage_1.effectiv_ind < 0.83::double precision
                        THEN 0.85
                    WHEN stage_1.effectiv_ind >= 0.83::double precision AND
                         stage_1.effectiv_ind < 0.85::double precision THEN 0.9
                    WHEN stage_1.effectiv_ind >= 0.85::double precision AND stage_1.effectiv_ind < 0.9::double precision
                        THEN 1::numeric
                    WHEN stage_1.effectiv_ind >= 0.9::double precision AND stage_1.effectiv_ind < 0.95::double precision
                        THEN 1.1
                    WHEN stage_1.effectiv_ind >= 0.95::double precision THEN 1.2
                    ELSE NULL::numeric
                    END AS koeff_effectiv_ind
         FROM stage_1
     ),
     stage_3 AS (
         SELECT stage_2.start_bw,
                stage_2.stop_bw,
                stage_2.num,
                stage_2.loan_id,
                stage_2.region,
                stage_2."group",
                stage_2.manager_fio,
                stage_2.agent_fio,
                stage_2.loan_number,
                stage_2.fio,
                stage_2.reg_adress,
                stage_2.fact_adress,
                stage_2.number,
                stage_2.company_name,
                stage_2.friends,
                stage_2.product_name,
                stage_2.loan_num_bw,
                stage_2.open_dt,
                stage_2.loan_sum,
                stage_2.plan_pay,
                stage_2.plan_pay_week,
                stage_2.balance,
                stage_2.pay_made,
                stage_2.status_name,
                stage_2.principal_debt,
                stage_2.total_debt,
                stage_2.pay_all_cum,
                stage_2.repaid_interest,
                stage_2.cumulat_principal,
                stage_2.current_overdue,
                stage_2.flg_overdue,
                stage_2.week_overdue,
                stage_2.cum_overdue,
                stage_2.pay_partial,
                stage_2.pay_full,
                stage_2.early_repayment_dt,
                stage_2.client_type,
                stage_2.award_issuance,
                stage_2.net_pay,
                stage_2.payments_cum,
                stage_2.effectiv_ind,
                stage_2.koeff_effectiv_ind,
                round(COALESCE(
                              CASE
                                  WHEN (stage_2.product_name::text = ANY
                                        (ARRAY ['Аннуитет'::character varying, 'Аннуитет 3'::character varying]::text[])) AND
                                       stage_2.payments_cum < 31::numeric THEN stage_2.net_pay * 0.08
                                  WHEN (stage_2.product_name::text = ANY
                                        (ARRAY ['Аннуитет'::character varying, 'Аннуитет 3'::character varying]::text[])) AND
                                       stage_2.payments_cum >= 31::numeric AND stage_2.payments_cum < 41::numeric
                                      THEN stage_2.net_pay * 0.1
                                  WHEN (stage_2.product_name::text = ANY
                                        (ARRAY ['Аннуитет'::character varying, 'Аннуитет 3'::character varying]::text[])) AND
                                       stage_2.payments_cum >= 41::numeric THEN stage_2.net_pay * 0.12
                                  WHEN stage_2.product_name::text = 'Аннуитет 2'::text AND stage_2.payments_cum < 24::numeric
                                      THEN stage_2.net_pay * 0.08
                                  WHEN stage_2.product_name::text = 'Аннуитет 2'::text AND
                                       stage_2.payments_cum >= 24::numeric AND stage_2.payments_cum < 31::numeric
                                      THEN stage_2.net_pay * 0.1
                                  WHEN stage_2.product_name::text = 'Аннуитет 2'::text AND stage_2.payments_cum >= 31::numeric
                                      THEN stage_2.net_pay * 0.12
                                  ELSE NULL::numeric
                                  END, 0::numeric) * stage_2.koeff_effectiv_ind, 2) +
                round(COALESCE(stage_2.pay_partial, 0::numeric) * 0.01, 2) + round(COALESCE(
                                                                                           CASE
                                                                                               WHEN stage_2.pay_full IS NOT NULL
                                                                                                   THEN stage_2.repaid_interest * 0.005
                                                                                               ELSE NULL::numeric
                                                                                               END, 0::numeric),
                                                                                   2) AS award_collecting,
                CASE
                    WHEN stage_2.loan_num_bw = max(stage_2.loan_num_bw) OVER (PARTITION BY stage_2.loan_id) AND
                         stage_2.status_name = 'Просрочен'::text AND stage_2.week_overdue > 6 OR
                         (stage_2.status_name = ANY
                          (ARRAY ['Закрыт'::text, 'Передано в суд'::text, 'Банкрот'::text, 'Клиент умер'::text, 'Передан по цессии'::text]))
                        THEN 'Вызрел'::text
                    ELSE 'Не вызрел'::text
                    END                                                               AS event_ripen
         FROM stage_2
     )
SELECT stage_3.start_bw,
       stage_3.stop_bw,
       stage_3.num,
       stage_3.loan_id,
       stage_3.region,
       stage_3."group",
       stage_3.manager_fio,
       stage_3.agent_fio,
       stage_3.loan_number,
       stage_3.fio,
       stage_3.reg_adress,
       stage_3.fact_adress,
       stage_3.number,
       stage_3.company_name,
       stage_3.friends,
       stage_3.product_name,
       stage_3.loan_num_bw,
       stage_3.open_dt,
       stage_3.loan_sum,
       stage_3.plan_pay,
       stage_3.plan_pay_week,
       stage_3.balance,
       stage_3.pay_made,
       stage_3.status_name,
       stage_3.principal_debt,
       stage_3.total_debt,
       stage_3.pay_all_cum,
       stage_3.repaid_interest,
       stage_3.cumulat_principal,
       stage_3.current_overdue,
       stage_3.flg_overdue,
       stage_3.week_overdue,
       stage_3.cum_overdue,
       stage_3.pay_partial,
       stage_3.pay_full,
       stage_3.early_repayment_dt,
       stage_3.client_type,
       stage_3.award_issuance,
       stage_3.net_pay,
       stage_3.payments_cum,
       stage_3.effectiv_ind,
       stage_3.koeff_effectiv_ind,
       stage_3.award_collecting,
       stage_3.event_ripen,
       CASE
           WHEN stage_3.loan_num_bw = 0 THEN
                       COALESCE(sum(stage_3.net_pay) OVER (PARTITION BY stage_3.loan_id), 0::numeric) +
                       COALESCE(sum(stage_3.pay_partial) OVER (PARTITION BY stage_3.loan_id), 0::numeric) +
                       COALESCE(sum(stage_3.pay_full) OVER (PARTITION BY stage_3.loan_id), 0::numeric) -
                       max(stage_3.loan_sum) OVER (PARTITION BY stage_3.loan_id) -
                       sum(stage_3.award_issuance) OVER (PARTITION BY stage_3.loan_id)::numeric -
                       COALESCE(sum(stage_3.award_collecting) OVER (PARTITION BY stage_3.loan_id), 0::numeric)
           ELSE NULL::numeric
           END                                                      AS fin_result,
       min(stage_3.event_ripen) OVER (PARTITION BY stage_3.loan_id) AS flg_ripen
FROM stage_3
UNION ALL
SELECT NULL::date                                                                           AS start_bw,
       NULL::date                                                                           AS stop_bw,
       NULL::integer                                                                        AS num,
       NULL::uuid                                                                           AS loan_id,
       sim.region_zp                                                                        AS region,
       sim.group_zp                                                                         AS "group",
       sim.manager_zp                                                                       AS manager_fio,
       NULL::text                                                                           AS agent_fio,
       NULL::character varying                                                              AS loan_number,
       NULL::text                                                                           AS fio,
       NULL::text                                                                           AS reg_adress,
       NULL::text                                                                           AS fact_adress,
       NULL::character varying                                                              AS number,
       NULL::character varying                                                              AS company_name,
       NULL::text                                                                           AS friends,
       NULL::character varying                                                              AS product_name,
       NULL::bigint                                                                         AS loan_num_bw,
       sim.period_zp::date                                                                  AS open_dt,
       NULL::numeric                                                                        AS loan_sum,
       NULL::numeric                                                                        AS plan_pay,
       NULL::numeric                                                                        AS plan_pay_week,
       NULL::numeric                                                                        AS balance,
       NULL::numeric                                                                        AS pay_made,
       NULL::text                                                                           AS status_name,
       NULL::numeric                                                                        AS principal_debt,
       NULL::numeric                                                                        AS total_debt,
       NULL::numeric                                                                        AS pay_all_cum,
       NULL::numeric                                                                        AS repaid_interest,
       NULL::numeric                                                                        AS cumulat_principal,
       NULL::integer                                                                        AS current_overdue,
       NULL::text                                                                           AS flg_overdue,
       NULL::bigint                                                                         AS week_overdue,
       NULL::bigint                                                                         AS cum_overdue,
       NULL::numeric                                                                        AS pay_partial,
       NULL::numeric                                                                        AS pay_full,
       NULL::date                                                                           AS early_repayment_dt,
       NULL::text                                                                           AS client_type,
       NULL::integer                                                                        AS award_issuance,
       NULL::numeric                                                                        AS net_pay,
       NULL::numeric                                                                        AS payments_cum,
       NULL::double precision                                                               AS effectiv_ind,
       NULL::numeric                                                                        AS koeff_effectiv_ind,
       NULL::numeric                                                                        AS award_collecting,
       NULL::text                                                                           AS event_ripen,
       - replace(replace(sim.total_zp, ','::text, '.'::text), ' '::text, ''::text)::numeric AS fin_result,
       'Вызрел'::text                                                                       AS flg_ripen
FROM _salary_install_managers sim;

alter materialized view mvw_agent_contracts_dl owner to "pz-zeppelin";

