create materialized view mvw_agent_contracts as
WITH buss_week_num AS (
    SELECT generate_series('2021-11-16 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '7 days'::interval)::date AS start_bw,
           generate_series('2021-11-23 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '7 days'::interval)::date AS stop_bw,
           generate_series(1, (CURRENT_DATE - '2021-11-16'::date) / 7, 1)                       AS num
),
     statuses AS (
         SELECT init_data.status_id,
                init_data.loan_id,
                init_data.user_id,
                init_data.loan_sum,
                init_data.status_name,
                init_data.start_stat,
                init_data.stop_stat,
                sum((init_data.stop_stat + '03:00:00'::interval)::date -
                    (init_data.start_stat + '03:00:00'::interval)::date + 1)
                FILTER (WHERE init_data.status_name = 'loan_overdue'::loansstatusenum) OVER (PARTITION BY init_data.loan_id ORDER BY init_data.start_stat) AS cum_overdue,
                CASE
                    WHEN init_data.num_pos = 1 THEN init_data.open_dt
                    ELSE NULL::timestamp without time zone
                    END                                                                                                                                    AS open_dt,
                CASE
                    WHEN init_data.num_pos = 1 THEN init_data.close_dt
                    ELSE NULL::timestamp without time zone
                    END                                                                                                                                    AS close_dt
         FROM (SELECT ls.status_id,
                      ls.loan_id,
                      l_1.user_id,
                      l_1.loan_sum,
                      ls.status_name,
                      ls.status_date + '03:00:00'::interval                         AS start_stat,
                      CASE
                          WHEN lead(ls.status_date + '03:00:00'::interval)
                               OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NULL
                              THEN (CURRENT_DATE + 1)::timestamp without time zone
                          ELSE lead(ls.status_date + '03:00:00'::interval)
                               OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id)
                          END                                                       AS stop_stat,
                      l_1.loan_issue_date + '03:00:00'::interval                    AS open_dt,
                      COALESCE(max(ls.status_date + '03:00:00'::interval) FILTER (WHERE ls.status_name = ANY
                                                                                        (ARRAY ['closed'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum, 'cession'::loansstatusenum])) OVER (PARTITION BY ls.loan_id),
                               (CURRENT_DATE + 1)::timestamp without time zone)     AS close_dt,
                      rank() OVER (PARTITION BY ls.loan_id ORDER BY ls.status_date) AS num_pos
               FROM loan_statuses ls
                        JOIN loans l_1 ON l_1.loan_id = ls.loan_id AND (l_1.product_id = ANY
                                                                        (ARRAY ['fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
                        JOIN loan_statuses_pk_map lspm ON ls.status_id = lspm.pz_id
               WHERE ls.is_deleted IS FALSE
                 AND (ls.status_name <> ALL
                      (ARRAY ['on_check'::loansstatusenum, 'setting_a_limit'::loansstatusenum, 'pending_issuance_request'::loansstatusenum, 'client_refusal'::loansstatusenum, 'money_transfer'::loansstatusenum, 'checking_new_client_a'::loansstatusenum, 'checking_repeat_client_a'::loansstatusenum, 'client_definition'::loansstatusenum, 'process_definition'::loansstatusenum, 'ab_test_new'::loansstatusenum, 'checking_new_client_b'::loansstatusenum, 'checking_repeat_client_b'::loansstatusenum, 'ab_test_old'::loansstatusenum, 'checking_new_client'::loansstatusenum, 'checking_repeat_client'::loansstatusenum, 'close_or_extend'::loansstatusenum, 'automatic_check'::loansstatusenum, 'underwriter_refusal'::loansstatusenum, 'loan_approved'::loansstatusenum, 'requesting_loan'::loansstatusenum, 'failure_automatic'::loansstatusenum, 'issuance_error'::loansstatusenum]))) init_data
         WHERE init_data.start_stat <> init_data.stop_stat
     ),
     shed_to_dt AS (
         WITH shed_vers AS (
             SELECT a.loan_id,
                    a.shed_version,
                    a.shed_begin_dt AS start_shed_dt,
                    CASE
                        WHEN lead(a.shed_begin_dt) OVER (PARTITION BY a.loan_id ORDER BY a.shed_begin_dt) IS NULL
                            THEN (CURRENT_DATE + 1)::timestamp without time zone
                        ELSE lead(a.shed_begin_dt) OVER (PARTITION BY a.loan_id ORDER BY a.shed_begin_dt)
                        END         AS stop_shed_dt
             FROM (SELECT DISTINCT ON (lps_1.loan_id, lps_1.schedule_number) lps_1.loan_id,
                                                                             lps_1.schedule_number AS shed_version,
                                                                             max(lps_1.paid_at + '03:00:00'::interval)
                                                                             FILTER (WHERE lps_1.payment_number = 1) OVER (PARTITION BY lps_1.loan_id, lps_1.schedule_number) -
                                                                             '7 days'::interval    AS shed_begin_dt
                   FROM loan_payment_scheme lps_1
                            JOIN loan_payment_scheme_pk_map lps_pk_1 ON lps_pk_1.pz_id = lps_1.scheme_id
                   ORDER BY lps_1.loan_id, lps_1.schedule_number, lps_pk_1.sc_id DESC) a
         )
         SELECT DISTINCT shed_vers.start_shed_dt,
                         shed_vers.stop_shed_dt,
                         shed_vers.shed_version,
                         lps.loan_id,
                         (lps.paid_at + '03:00:00'::interval)::date                                        AS paid_at,
                         lps.principal_debt,
                         lps.payment_amount,
                         lps.interest_debt,
                         lps.write_off_principal_debt,
                         max((lps.paid_at + '03:00:00'::interval)::date)
                         OVER (PARTITION BY lps.loan_id)                                                   AS plan_close_dt,
                         sum(lps.write_off_principal_debt)
                         OVER (PARTITION BY lps.loan_id, shed_vers.shed_version ORDER BY lps.paid_at DESC) AS cumulat_principal
         FROM shed_vers
                  JOIN loan_payment_scheme lps
                       ON shed_vers.loan_id = lps.loan_id AND shed_vers.shed_version = lps.schedule_number
                  JOIN loan_payment_scheme_pk_map lps_pk ON lps_pk.pz_id = lps.scheme_id
     ),
     balances AS (
         SELECT DISTINCT ON (b.loan_id, buss_week_num_1.num) buss_week_num_1.start_bw,
                                                             buss_week_num_1.stop_bw,
                                                             buss_week_num_1.num,
                                                             b.loan_id,
                                                             b.trans_date AS chang_bal_dttm,
                                                             b.balance
         FROM buss_week_num buss_week_num_1
                  LEFT JOIN (SELECT a.loan_id,
                                    a.trans_date + '03:00:00'::interval                               AS trans_date,
                                    sum(a.amount) OVER (PARTITION BY a.loan_id ORDER BY a.trans_date) AS balance
                             FROM (SELECT tah.added_at   AS trans_date,
                                          tah.record_sum AS amount,
                                          tah.loan_id
                                   FROM tmp_account_history tah
                                            JOIN loans l_1 ON l_1.loan_id = tah.loan_id AND (l_1.product_id = ANY
                                                                                             (ARRAY ['fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
                                   WHERE tah.type_record_id <> 1
                                     AND (tah.method::text = ANY
                                          (ARRAY ['mandarinpay'::character varying, 'tinkoff'::character varying, 'cash'::character varying, 'cashless_payment'::character varying, 'unknown'::character varying]::text[]))
                                   UNION ALL
                                   SELECT tah.added_at     AS trans_date,
                                          - tah.record_sum AS amount,
                                          tah.loan_id
                                   FROM tmp_account_history tah
                                            JOIN loans l_1 ON l_1.loan_id = tah.loan_id AND (l_1.product_id = ANY
                                                                                             (ARRAY ['fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
                                   WHERE tah.type_record_id <> 1
                                     AND tah.debt_id IS NOT NULL) a) b ON b.trans_date < buss_week_num_1.stop_bw
         ORDER BY b.loan_id, buss_week_num_1.num, b.trans_date DESC
     ),
     debt_mod AS (
         SELECT DISTINCT ON (d.loan_id, buss_week_num_1.start_bw) d.loan_id,
                                                                  d.total_debt,
                                                                  d.principal_debt,
                                                                  buss_week_num_1.start_bw
         FROM debt d
                  JOIN debt_pk_map d_pk ON d_pk.pz_id = d.debt_id
                  JOIN buss_week_num buss_week_num_1
                       ON d.added_at >= buss_week_num_1.start_bw AND d.added_at <= buss_week_num_1.stop_bw
         ORDER BY d.loan_id, buss_week_num_1.start_bw, d_pk.sc_id DESC
     ),
     payments AS (
         SELECT a.start_bw,
                a.loan_id,
                a.pay_made,
                a.pay_partial,
                a.pay_full,
                a.pay_all,
                sum(a.pay_all) OVER (PARTITION BY a.loan_id ORDER BY a.start_bw) AS pay_all_cum
         FROM (SELECT buss_week_num_1.start_bw,
                      tah.loan_id,
                      sum(
                              CASE
                                  WHEN (tah.type_record_id = ANY (ARRAY [2, 14])) AND (tah.method::text = ANY
                                                                                       (ARRAY ['mandarinpay'::character varying, 'tinkoff'::character varying, 'cash'::character varying, 'cashless_payment'::character varying, 'unknown'::character varying]::text[])) OR
                                       tah.type_record_id = 5 THEN tah.record_sum
                                  ELSE NULL::numeric
                                  END) AS pay_made,
                      sum(
                              CASE
                                  WHEN tah.type_record_id = 7 THEN tah.record_sum
                                  ELSE NULL::numeric
                                  END) AS pay_partial,
                      sum(
                              CASE
                                  WHEN tah.type_record_id = 5 THEN tah.record_sum
                                  ELSE NULL::numeric
                                  END) AS pay_full,
                      sum(
                              CASE
                                  WHEN (tah.type_record_id = ANY (ARRAY [2, 14])) AND (tah.method::text = ANY
                                                                                       (ARRAY ['mandarinpay'::character varying, 'tinkoff'::character varying, 'cash'::character varying, 'cashless_payment'::character varying, 'unknown'::character varying]::text[])) OR
                                       (tah.type_record_id = ANY (ARRAY [5, 7])) THEN tah.record_sum
                                  ELSE NULL::numeric
                                  END) AS pay_all
               FROM tmp_account_history tah
                        JOIN loans l_1 ON l_1.loan_id = tah.loan_id AND (l_1.product_id = ANY
                                                                         (ARRAY ['fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
                        JOIN buss_week_num buss_week_num_1
                             ON (tah.added_at + '03:00:00'::interval) >= buss_week_num_1.start_bw AND
                                (tah.added_at + '03:00:00'::interval) <= buss_week_num_1.stop_bw
               WHERE tah.type_record_id <> ALL (ARRAY [1, 15])
               GROUP BY buss_week_num_1.start_bw, tah.loan_id) a
         ORDER BY a.start_bw
     ),
     loan_receipts AS (
         SELECT init_data.start_bw,
                init_data.loan_id,
                sum(init_data.interest_repayment) AS interest_repayment
         FROM (SELECT buss_week_num_1.start_bw,
                      d.loan_id,
                      lag(d.interest_debt) OVER (PARTITION BY d.loan_id ORDER BY dpm.sc_id) -
                      d.interest_debt AS interest_repayment
               FROM debt d
                        JOIN debt_pk_map dpm ON d.debt_id = dpm.pz_id
                        JOIN buss_week_num buss_week_num_1
                             ON (d.added_at + '03:00:00'::interval) >= buss_week_num_1.start_bw AND
                                (d.added_at + '03:00:00'::interval) <= buss_week_num_1.stop_bw) init_data
         WHERE init_data.interest_repayment >= 0::numeric
         GROUP BY init_data.start_bw, init_data.loan_id
         ORDER BY init_data.start_bw
     ),
     agent AS (
         SELECT DISTINCT ON (ls.loan_id) ls.loan_id,
                                         (((adm.last_name::text || ' '::text) || adm.first_name::text) || ' '::text) ||
                                         adm.middle_name::text AS agent_fio,
                                         ash.manager           AS manager_fio,
                                         ash.division          AS "group",
                                         ash.region
         FROM loan_statuses ls
                  JOIN loans l_1 ON l_1.loan_id = ls.loan_id
                  LEFT JOIN admins adm ON ls.admin_id = adm.admin_id
                  LEFT JOIN _agents_shedule ash ON ash.agent =
                                                   ((((adm.last_name::text || ' '::text) || adm.first_name::text) ||
                                                     ' '::text) || adm.middle_name::text)
         WHERE ls.is_deleted IS FALSE
           AND ls.status_name = 'automatic_check'::loansstatusenum
         ORDER BY ls.loan_id, ls.status_date DESC
     )
SELECT buss_week_num.start_bw,
       buss_week_num.stop_bw - 1                                                                                        AS stop_bw,
       buss_week_num.num,
       st1.loan_id,
       agent.region,
       agent."group",
       agent.manager_fio,
       agent.agent_fio,
       l.loan_number,
       (((pass.last_name::text || ' '::text) || pass.first_name::text) || ' '::text) ||
       pass.middle_name::text                                                                                           AS fio,
       (((((((((((((k_r.region::text || ' '::text) || k_r.district::text) || ' '::text) || k_r.city::text) ||
                ' ул.'::text) || k_r.street::text) || ' д.'::text) || k_r.house_number::text) || ' '::text) ||
           k_r.block::text) || ' '::text) || k_r.building::text) || ' кв.'::text) ||
       k_r.apartment::text                                                                                              AS reg_adress,
       (((((((((((((k_f.region::text || ' '::text) || k_f.district::text) || ' '::text) || k_f.city::text) ||
                ' ул.'::text) || k_f.street::text) || ' д.'::text) || k_f.house_number::text) || ' '::text) ||
           k_f.block::text) || ' '::text) || k_f.building::text) || ' кв.'::text) ||
       k_f.apartment::text                                                                                              AS fact_adress,
       pn.number,
       us.company_name,
       uf.friends,
       p.product_name,
       rank() OVER (PARTITION BY st1.loan_id ORDER BY buss_week_num.start_bw) -
       1                                                                                                                AS loan_num_bw,
       st1.open_dt::date                                                                                                AS open_dt,
       st1.loan_sum,
       CASE
           WHEN st2.status_name = 'loan_overdue'::loansstatusenum THEN count(st1.status_id)
                                                                       FILTER (WHERE st2.status_name = 'loan_overdue'::loansstatusenum) OVER (PARTITION BY st1.loan_id, st1.status_id ORDER BY buss_week_num.start_bw)::numeric *
                                                                       plan_shed.payment_amount - COALESCE(
                                                                                       sum(payments.pay_made)
                                                                                       FILTER (WHERE st2.status_name = 'loan_overdue'::loansstatusenum) OVER (PARTITION BY st1.loan_id, st1.status_id ORDER BY buss_week_num.start_bw),
                                                                                       0::numeric)
           ELSE plan_shed.payment_amount
           END                                                                                                          AS plan_pay,
       round(l.loan_sum * (l.credit_rate * 7::numeric / 100::numeric *
                           ((1::numeric + l.credit_rate * 7::numeric / 100::numeric) ^ l.loan_period::numeric) /
                           (((1::numeric + l.credit_rate * 7::numeric / 100::numeric) ^ l.loan_period::numeric) -
                            1::numeric)),
             2)                                                                                                         AS plan_pay_week,
       balances.balance,
       payments.pay_made,
       CASE
           WHEN st2.status_name::text = 'loan_overdue'::text THEN 'Просрочен'::text
           WHEN st2.status_name::text = 'closed'::text THEN 'Закрыт'::text
           WHEN st2.status_name::text = 'loan_approved'::text THEN 'Займ одобрен'::text
           WHEN st2.status_name::text = 'loan_issued'::text THEN 'Займ выдан'::text
           WHEN st2.status_name::text = 'loan_extended'::text THEN 'Займ продлен'::text
           WHEN st2.status_name::text = 'loan_repayment_date'::text THEN 'День погашения займа'::text
           WHEN st2.status_name::text = 'close_or_extend'::text THEN 'Проверка на закрытие или продление займа'::text
           WHEN st2.status_name::text = 'submitted_to_court'::text THEN 'Передано в суд'::text
           WHEN st2.status_name::text = 'period_paid'::text THEN 'Период оплачен'::text
           WHEN st2.status_name::text = 'bankrupt'::text THEN 'Банкрот'::text
           WHEN st2.status_name::text = 'client_died'::text THEN 'Клиент умер'::text
           WHEN st2.status_name::text = 'cession'::text THEN 'Передан по цессии'::text
           WHEN st2.status_name::text = 'temp_close'::text THEN 'Предварительно закрыт'::text
           ELSE st2.status_name::text
           END                                                                                                          AS status_name,
       dm.principal_debt,
       dm.total_debt,
       max(payments.pay_all_cum)
       OVER (PARTITION BY st1.loan_id ORDER BY buss_week_num.start_bw ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS pay_all_cum,
       sum(loan_receipts.interest_repayment)
       OVER (PARTITION BY st1.loan_id ORDER BY buss_week_num.start_bw)                                                  AS repaid_interest,
       CASE
           WHEN st2.status_name = ANY
                (ARRAY ['closed'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum, 'cession'::loansstatusenum, 'temp_close'::loansstatusenum])
               THEN 0::numeric
           ELSE shed_to_dt.cumulat_principal
           END                                                                                                          AS cumulat_principal,
       CASE
           WHEN st2.status_name = 'loan_overdue'::loansstatusenum THEN buss_week_num.stop_bw - st2.start_stat::date
           ELSE NULL::integer
           END                                                                                                          AS current_overdue,
       CASE
           WHEN st2.status_name = 'loan_overdue'::loansstatusenum THEN 'Да'::text
           ELSE NULL::text
           END                                                                                                          AS flg_overdue,
       CASE
           WHEN st2.status_name = 'loan_overdue'::loansstatusenum THEN count(st1.status_id)
                                                                       FILTER (WHERE st2.status_name = 'loan_overdue'::loansstatusenum) OVER (PARTITION BY st1.loan_id, st1.status_id ORDER BY buss_week_num.start_bw)
           ELSE NULL::bigint
           END                                                                                                          AS week_overdue,
       st2.cum_overdue,
       payments.pay_partial,
       payments.pay_full,
       CASE
           WHEN st2.status_name = 'closed'::loansstatusenum AND st2.start_stat::date < shed_to_dt.plan_close_dt
               THEN shed_to_dt.plan_close_dt
           ELSE NULL::date
           END                                                                                                          AS early_repayment_dt,
       CASE
           WHEN rank() OVER (PARTITION BY st1.user_id ORDER BY st1.open_dt) = 1 THEN 'Первичный'::text
           ELSE 'Повторный'::text
           END                                                                                                          AS client_type
FROM buss_week_num
         LEFT JOIN statuses st1
                   ON (buss_week_num.start_bw + 7) >= st1.open_dt AND (buss_week_num.stop_bw - 7) < st1.close_dt
         LEFT JOIN statuses st2 ON st1.loan_id = st2.loan_id AND buss_week_num.stop_bw >= st2.start_stat AND
                                   buss_week_num.stop_bw < st2.stop_stat
         LEFT JOIN debt_mod dm ON dm.loan_id = st1.loan_id AND dm.start_bw = buss_week_num.start_bw
         LEFT JOIN shed_to_dt
                   ON shed_to_dt.loan_id = st1.loan_id AND buss_week_num.stop_bw >= shed_to_dt.start_shed_dt AND
                      buss_week_num.stop_bw <= shed_to_dt.stop_shed_dt AND
                      (shed_to_dt.paid_at - 7) >= buss_week_num.start_bw AND
                      (shed_to_dt.paid_at - 7) < buss_week_num.stop_bw
         LEFT JOIN shed_to_dt plan_shed
                   ON plan_shed.loan_id = st1.loan_id AND buss_week_num.stop_bw >= plan_shed.start_shed_dt AND
                      buss_week_num.stop_bw <= plan_shed.stop_shed_dt AND plan_shed.paid_at >= buss_week_num.stop_bw AND
                      plan_shed.paid_at < (buss_week_num.stop_bw + 7)
         LEFT JOIN balances ON balances.loan_id = st1.loan_id AND balances.stop_bw = buss_week_num.stop_bw
         LEFT JOIN payments ON payments.loan_id = st1.loan_id AND payments.start_bw = buss_week_num.start_bw
         LEFT JOIN loan_receipts
                   ON loan_receipts.loan_id = st1.loan_id AND loan_receipts.start_bw = buss_week_num.start_bw
         LEFT JOIN loans l ON l.loan_id = st1.loan_id
         LEFT JOIN products p ON l.product_id = p.product_id
         LEFT JOIN passport pass ON pass.user_id = l.user_id
         LEFT JOIN kladr k_r ON pass.registration_address_id = k_r.id
         LEFT JOIN kladr k_f ON pass.actual_address_id = k_f.id
         LEFT JOIN phone_numbers pn ON pn.user_id = l.user_id AND pn.number_type = 'mobile'::phonenumbertypesenum AND
                                       pn.is_active IS TRUE AND pn.is_default IS TRUE
         LEFT JOIN user_details us ON us.user_id = l.user_id
         LEFT JOIN (SELECT user_friends.user_id,
                           string_agg((((((((user_friends.friend_type || ': '::text) || user_friends.last_name::text) ||
                                           ' '::text) || user_friends.first_name::text) || ' '::text) ||
                                        user_friends.middle_name::text) || ', тел'::text) || user_friends.phone::text,
                                      '; '::text) AS friends
                    FROM user_friends
                    GROUP BY user_friends.user_id) uf ON uf.user_id = l.user_id
         LEFT JOIN agent ON agent.loan_id = st1.loan_id
ORDER BY buss_week_num.start_bw;

alter materialized view mvw_agent_contracts owner to "pz-zeppelin";

