create materialized view mvw_collector_listing as
WITH overdue_loans AS (
    SELECT ls.loan_id
    FROM last_loan_status lls
             JOIN loan_statuses ls ON ls.status_id = lls.status_id AND ls.status_name = 'loan_overdue'::loansstatusenum
),
     calc_overdue AS (
         SELECT calc_overdue.loan_id,
                sum(
                        CASE
                            WHEN calc_overdue.status_name = 'loan_overdue'::loansstatusenum
                                THEN calc_overdue.stop_stat::date - calc_overdue.start_stat::date
                            ELSE 0
                            END) AS total_overdue
         FROM (SELECT ls.loan_id,
                      ls.status_name,
                      ls.status_date AS start_stat,
                      CASE
                          WHEN lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NULL
                              THEN CURRENT_DATE::timestamp without time zone
                          ELSE lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id)
                          END        AS stop_stat
               FROM overdue_loans l_1
                        JOIN loan_statuses ls ON l_1.loan_id = ls.loan_id AND ls.is_deleted IS FALSE
                        JOIN loan_statuses_pk_map lspm ON ls.status_id = lspm.pz_id) calc_overdue
         WHERE calc_overdue.start_stat <> calc_overdue.stop_stat
         GROUP BY calc_overdue.loan_id
     ),
     last_collector_task AS (
         SELECT DISTINCT ON (ct.loan_id) ct.loan_id,
                                         ct.created_at + '03:00:00'::interval AS task_dttm,
                                         ct.task_status                       AS collector_status
         FROM collector_tasks ct
         ORDER BY ct.loan_id, ct.created_at DESC
     ),
     securing AS (
         SELECT DISTINCT ON (cw.loan_id) cw.loan_id,
                                         a.username,
                                         cw.stop_date
         FROM collector_works cw
                  JOIN admins a ON a.admin_id = cw.admin_id
         ORDER BY cw.loan_id, cw.start_date DESC
     )
SELECT l.loan_number,
       l.loan_date_create + '03:00:00'::interval                                                      AS "?column?",
       co.total_overdue,
       (((p.first_name::text || ' '::text) || p.last_name::text) || ' '::text) || p.middle_name::text AS fio,
       pn.number                                                                                      AS phone_number,
       kladr.city,
       l.loan_sum,
       securing.username,
       u.time_zone,
       lct.task_dttm,
       lct.collector_status,
       (p.serial::text || ' '::text) || p.number::text                                                AS passport
FROM calc_overdue co
         JOIN loans l ON l.loan_id = co.loan_id
         JOIN passport p ON p.user_id = l.user_id
         JOIN phone_numbers pn ON pn.user_id = l.user_id AND pn.is_default IS TRUE AND pn.is_active IS TRUE
         JOIN users u ON l.user_id = u.user_id
         LEFT JOIN kladr ON p.actual_address_id = kladr.id
         LEFT JOIN securing ON securing.loan_id = l.loan_id AND securing.stop_date IS NULL
         LEFT JOIN last_collector_task lct ON lct.loan_id = l.loan_id;

alter materialized view mvw_collector_listing owner to kchernyshev;

