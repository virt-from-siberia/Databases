create materialized view mvw_cash_balance as
SELECT sel.trans_date,
       COALESCE(sum(sel."out"), 0::numeric)                                       AS "out",
       COALESCE(sum(sel."in"), 0::numeric)                                        AS "in",
       COALESCE(sum(sel."in"), 0::numeric) - COALESCE(sum(sel."out"), 0::numeric) AS diff,
       sel.product_name,
       sel.is_loan_repeated,
       sum(sel.cnt_out)                                                           AS cnt_out,
       sum(sel.cnt_in)                                                            AS cnt_in
FROM (SELECT (t.trans_date + '03:00:00'::interval)::date AS trans_date,
             p.product_name,
             CASE
                 WHEN l.is_loan_repeated = true THEN 'Повторная'::text
                 ELSE 'Первичная'::text
                 END                                     AS is_loan_repeated,
             - sum(
                     CASE
                         WHEN t.amount < 0::numeric THEN t.amount
                         ELSE 0::numeric
                         END)                            AS "out",
             sum(
                     CASE
                         WHEN t.amount > 0::numeric THEN t.amount
                         ELSE 0::numeric
                         END)                            AS "in",
             count(DISTINCT
                   CASE
                       WHEN t.amount < 0::numeric THEN l.loan_id
                       ELSE NULL::uuid
                       END)                              AS cnt_out,
             count(DISTINCT
                   CASE
                       WHEN t.amount > 0::numeric THEN l.loan_id
                       ELSE NULL::uuid
                       END)                              AS cnt_in
      FROM transactions t
               JOIN loans l USING (loan_id)
               JOIN products p USING (product_id)
      WHERE (t.trans_date + '03:00:00'::interval) < CURRENT_DATE
      GROUP BY ((t.trans_date + '03:00:00'::interval)::date), p.product_name, l.is_loan_repeated) sel
GROUP BY sel.trans_date, sel.product_name, sel.is_loan_repeated
ORDER BY sel.trans_date DESC;

alter materialized view mvw_cash_balance owner to "pz-zeppelin";

