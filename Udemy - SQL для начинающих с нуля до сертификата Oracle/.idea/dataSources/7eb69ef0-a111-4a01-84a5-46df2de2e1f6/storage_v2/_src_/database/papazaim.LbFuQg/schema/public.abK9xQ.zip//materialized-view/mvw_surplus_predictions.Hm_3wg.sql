create materialized view mvw_surplus_predictions as
WITH correction_forecast AS (
    SELECT sp.open_dt::date AS open_dt,
           sp.loan_num_period,
           sp.loan_issuance,
           sp.defolt        AS defolt_forecast,
           CASE
               WHEN sp.fraction_non_overdue_debt < 0::double precision THEN max(sp.surplus_forecast)
                                                                            FILTER (WHERE sp.fraction_non_overdue_debt > 0::double precision) OVER (PARTITION BY sp.open_dt)
               ELSE sp.surplus_forecast
               END          AS surplus_forecast
    FROM _surplus_predictions sp
)
SELECT correction_forecast.open_dt,
       correction_forecast.loan_num_period,
       correction_forecast.loan_issuance,
       correction_forecast.defolt_forecast,
       correction_forecast.surplus_forecast
FROM correction_forecast
WHERE (correction_forecast.open_dt + ((correction_forecast.loan_num_period || ' month'::text)::interval)) >
      date_trunc('month'::text, CURRENT_DATE::timestamp with time zone);

alter materialized view mvw_surplus_predictions owner to "pz-zeppelin";

