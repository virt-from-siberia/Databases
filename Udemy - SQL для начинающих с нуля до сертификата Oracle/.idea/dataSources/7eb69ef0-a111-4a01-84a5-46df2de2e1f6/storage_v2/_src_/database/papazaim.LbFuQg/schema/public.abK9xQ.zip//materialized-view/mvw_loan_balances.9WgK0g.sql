create materialized view mvw_loan_balances as
WITH calendar AS (
    SELECT generate_series('2020-08-01 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '1 day'::interval)::date AS check_dt
),
     statuses AS (
         SELECT ls.status_id,
                ls.loan_id,
                ls.status_name,
                ls.status_date                                                                                                                                                                                                   AS start_status,
                CASE
                    WHEN lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NOT NULL THEN lead(
                                                                                                                  ls.status_date)
                                                                                                                  OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id)
                    WHEN ls.status_name = ANY
                         (ARRAY ['closed'::loansstatusenum, 'closed_overdue'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum, 'cession'::loansstatusenum])
                        THEN ls.status_date::date::timestamp without time zone
                    WHEN lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NULL
                        THEN (CURRENT_DATE + 1)::timestamp without time zone
                    ELSE NULL::timestamp without time zone
                    END                                                                                                                                                                                                          AS stop_status,
                max(ls.status_date::date)
                FILTER (WHERE ls.status_name = 'cession'::loansstatusenum) OVER (PARTITION BY ls.loan_id)                                                                                                                        AS cession_dt,
                max(ls.status_date::date) FILTER (WHERE ls.status_name = ANY
                                                        (ARRAY ['cession'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum, 'submitted_to_court'::loansstatusenum])) OVER (PARTITION BY ls.loan_id) AS forced_closure_dt
         FROM loan_statuses ls
                  JOIN loan_statuses_pk_map lspm ON ls.status_id = lspm.pz_id
         WHERE ls.is_deleted IS FALSE
           AND (ls.status_name <> ALL
                (ARRAY ['on_check'::loansstatusenum, 'setting_a_limit'::loansstatusenum, 'pending_issuance_request'::loansstatusenum, 'underwriter_refusal'::loansstatusenum, 'failure_automatic'::loansstatusenum, 'client_refusal'::loansstatusenum, 'loan_approved'::loansstatusenum, 'requesting_loan'::loansstatusenum, 'money_transfer'::loansstatusenum, 'checking_new_client_a'::loansstatusenum, 'checking_repeat_client_a'::loansstatusenum, 'client_definition'::loansstatusenum, 'process_definition'::loansstatusenum, 'ab_test_new'::loansstatusenum, 'checking_new_client_b'::loansstatusenum, 'checking_repeat_client_b'::loansstatusenum, 'ab_test_old'::loansstatusenum, 'checking_new_client'::loansstatusenum, 'checking_repeat_client'::loansstatusenum, 'close_or_extend'::loansstatusenum, 'automatic_check'::loansstatusenum]))
     ),
     service_debts AS (
         SELECT service_debt_total.loan_id,
                service_debt_total.start_debt,
                service_debt_total.stop_debt,
                sum(service_debt_total.service_debt) AS service_debt
         FROM (SELECT a.loan_id,
                      a.changed_at AS start_debt,
                      CASE
                          WHEN lead(a.changed_at) OVER w IS NOT NULL THEN lead(a.changed_at) OVER w
                          WHEN lead(a.changed_at) OVER w IS NULL THEN CURRENT_DATE + 1
                          ELSE NULL::date
                          END      AS stop_debt,
                      a.service_debt
               FROM (SELECT DISTINCT loan_services_debts.loan_id,
                                     loan_services_debts.changed_at::date                                                                                                 AS changed_at,
                                     first_value(loan_services_debts.service_debt)
                                     OVER (PARTITION BY loan_services_debts.loan_id, (loan_services_debts.changed_at::date) ORDER BY loan_services_debts.changed_at DESC) AS service_debt
                     FROM loan_services_debts) a
               WHERE a.service_debt > 0::numeric
                   WINDOW w AS (PARTITION BY a.loan_id ORDER BY a.changed_at)
               UNION ALL
               SELECT ls.loan_id,
                      ls.activated_at::date AS start_debt,
                      CURRENT_DATE + 1      AS stop_debt,
                      ls.service_sum
               FROM loan_services ls
               WHERE ls.service_type = 'payment_service_accelerated_review'::servicetypeenum
                 AND ls.service_status = 'service_is_activated'::servicestatusenum) service_debt_total
         GROUP BY service_debt_total.loan_id, service_debt_total.start_debt, service_debt_total.stop_debt
     ),
     loan_fake AS (
         SELECT l.loan_id
         FROM loans l
                  LEFT JOIN passport p ON p.user_id = l.user_id AND (p.serial::text || p.number::text) = '1817372752'::text
                  LEFT JOIN phone_numbers pn ON l.user_id = pn.user_id AND pn.is_default IS TRUE AND
                                                (pn.number::text = ANY
                                                 (ARRAY ['+79999999821'::character varying, '+79999999822'::character varying]::text[]))
         WHERE p.user_id IS NOT NULL
            OR pn.user_id IS NOT NULL
     ),
     stage_1 AS (
         SELECT statuses.loan_id,
                statuses.status_name,
                statuses.status_id,
                statuses.start_status + '03:00:00'::interval AS start_status,
                statuses.stop_status + '03:00:00'::interval  AS stop_status,
                ad.principal_debt,
                ad.interest_debt,
                ad.added_at + '03:00:00'::interval           AS added_at,
                statuses.cession_dt,
                statuses.forced_closure_dt
         FROM statuses
                  JOIN debt ad ON ad.loan_id = statuses.loan_id AND
                                  NOT (statuses.status_name = 'loan_overdue'::loansstatusenum AND
                                       statuses.start_status = statuses.stop_status) AND
                                  ad.added_at >= statuses.start_status AND ad.added_at <= statuses.stop_status
                  LEFT JOIN loan_fake ON loan_fake.loan_id = statuses.loan_id
         WHERE loan_fake.loan_id IS NULL
     )
SELECT calendar.check_dt,
       stage_1.loan_id,
       min(
               CASE
                   WHEN stage_1.status_name = 'loan_overdue'::loansstatusenum THEN stage_1.status_id::text
                   ELSE NULL::text
                   END)                AS status_id_overdue,
       min(stage_1.status_name)        AS status_name,
       min(stage_1.start_status)::date AS start_status,
       max(stage_1.stop_status)::date  AS stop_status,
       max(stage_1.added_at)           AS added_at,
       min(stage_1.principal_debt)     AS principal_debt,
       max(stage_1.interest_debt)      AS interest_debt,
       max(service_debts.service_debt) AS service_debt,
       max(stage_1.cession_dt)         AS cession_dt,
       max(stage_1.forced_closure_dt)  AS forced_closure_dt
FROM calendar
         LEFT JOIN stage_1 ON calendar.check_dt = stage_1.added_at::date
         LEFT JOIN service_debts
                   ON stage_1.loan_id = service_debts.loan_id AND calendar.check_dt >= service_debts.start_debt AND
                      calendar.check_dt <= (service_debts.stop_debt - 1)
GROUP BY calendar.check_dt, stage_1.loan_id
ORDER BY calendar.check_dt;

alter materialized view mvw_loan_balances owner to "pz-zeppelin";

create index ix_mvw_lbalance_loan_id
    on mvw_loan_balances (loan_id);

