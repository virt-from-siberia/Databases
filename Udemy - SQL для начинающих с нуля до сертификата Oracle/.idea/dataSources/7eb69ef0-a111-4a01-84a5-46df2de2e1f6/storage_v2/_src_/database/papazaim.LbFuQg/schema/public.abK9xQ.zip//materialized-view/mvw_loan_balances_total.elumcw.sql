create materialized view mvw_loan_balances_total as
WITH calendar AS (
    SELECT generate_series('2020-08-01 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '1 day'::interval)::date AS check_dt
),
     agents AS (
         SELECT DISTINCT ON (ls.loan_id) ls.loan_id,
                                         (((adm.last_name::text || ' '::text) || adm.first_name::text) || ' '::text) ||
                                         adm.middle_name::text AS agent_fio,
                                         ash.manager           AS manager_fio,
                                         ash.division          AS "group",
                                         ash.region
         FROM loan_statuses ls
                  JOIN loans l ON l.loan_id = ls.loan_id
                  LEFT JOIN admins adm ON ls.admin_id = adm.admin_id
                  LEFT JOIN _agents_shedule ash ON ash.agent =
                                                   ((((adm.last_name::text || ' '::text) || adm.first_name::text) ||
                                                     ' '::text) || adm.middle_name::text)
         WHERE ls.is_deleted IS FALSE
           AND ls.status_name = 'automatic_check'::loansstatusenum
         ORDER BY ls.loan_id, ls.status_date DESC
     ),
     underwriters AS (
         SELECT DISTINCT liw.loan_id,
                         first_value((((adm.last_name::text || ' '::text) || adm.first_name::text) || ' '::text) ||
                                     adm.middle_name::text)
                         OVER (PARTITION BY liw.loan_id ORDER BY liw.start_date DESC) AS underwriter_fio
         FROM loans_in_work liw
                  JOIN admins adm ON adm.admin_id = liw.admin_id
                  JOIN loans l ON l.loan_id = liw.loan_id AND (l.product_id = ANY
                                                               (ARRAY ['1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, 'fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
         WHERE liw.start_date < l.loan_issue_date
     ),
     surplas_loans AS (
         SELECT DISTINCT calendar.check_dt,
                         mlb.loan_id
         FROM calendar
                  LEFT JOIN mvw_loan_balances mlb
                            ON calendar.check_dt >= mlb.start_status AND calendar.check_dt <= CURRENT_DATE
                  LEFT JOIN loans l ON l.loan_id = mlb.loan_id AND (l.product_id = ANY
                                                                    (ARRAY ['1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, 'fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
         WHERE l.loan_id IS NOT NULL
     ),
     issuance_for_default AS (
         WITH pay_for_def AS (
             SELECT DISTINCT mlb2.loan_id,
                             (date_trunc('month'::text, mlb2.check_dt::timestamp with time zone) + '1 mon'::interval -
                              '1 day'::interval)::date                                                                                            AS month_repayment,
                             sum(tah.record_sum)
                             OVER (PARTITION BY mlb2.loan_id ORDER BY (date_trunc('month'::text, mlb2.check_dt::timestamp with time zone)::date)) AS amount_cum
             FROM surplas_loans mlb2
                      LEFT JOIN tmp_account_history tah ON mlb2.loan_id = tah.loan_id AND
                                                           (tah.added_at + '03:00:00'::interval)::date = mlb2.check_dt AND
                                                           tah.type_record_id <> 1 AND (tah.method::text = ANY
                                                                                        (ARRAY ['mandarinpay'::character varying, 'tinkoff'::character varying, 'cash'::character varying, 'cashless_payment'::character varying, 'unknown'::character varying]::text[]))
             UNION ALL
             SELECT tah.loan_id,
                    CURRENT_DATE - 1    AS month_repayment,
                    sum(tah.record_sum) AS amount_cum
             FROM tmp_account_history tah
                      JOIN loans l ON l.loan_id = tah.loan_id AND (l.product_id = ANY
                                                                   (ARRAY ['1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, 'fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
             WHERE tah.type_record_id <> 1
               AND (tah.method::text = ANY
                    (ARRAY ['mandarinpay'::character varying, 'tinkoff'::character varying, 'cash'::character varying, 'cashless_payment'::character varying, 'unknown'::character varying]::text[]))
               AND date_part('day'::text, CURRENT_DATE) <> 1::double precision
             GROUP BY tah.loan_id, (CURRENT_DATE - 1)
         ),
              pdp AS (
                  SELECT DISTINCT ON (l.loan_id) l.loan_id,
                                                 date_trunc('month'::text, ls2.status_date + '03:00:00'::interval)::date AS close_mnth
                  FROM loans l
                           JOIN loan_statuses ls2
                                ON ls2.loan_id = l.loan_id AND ls2.is_deleted IS FALSE AND ls2.status_name = 'closed'::loansstatusenum
                  WHERE (l.product_id = ANY
                         (ARRAY ['1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, 'fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
                    AND ((l.loan_issue_date + '03:00:00'::interval)::date + l.selected_loan_period * 7) >
                        (ls2.status_date + '03:00:00'::interval)::date
                  ORDER BY l.loan_id, ls2.status_date DESC
              )
         SELECT c2.check_dt,
                date_trunc('month'::text, l2.loan_issue_date + '03:00:00'::interval)::date AS month_issue,
                CASE
                    WHEN l2.is_loan_repeated = true THEN 'Повторная'::text
                    ELSE 'Первичная'::text
                    END                                                                    AS is_loan_repeated,
                p2.product_name,
                agents.agent_fio,
                un.underwriter_fio,
                max(agents.manager_fio)                                                    AS manager_fio,
                max(agents."group")                                                        AS "group",
                max(agents.region)                                                         AS region,
                sum(
                        CASE
                            WHEN c2.check_dt <> (CURRENT_DATE - 1) THEN l2.loan_sum
                            ELSE NULL::numeric
                            END)                                                           AS loan_sum_generation,
                sum(
                        CASE
                            WHEN c2.check_dt = (CURRENT_DATE - 1) THEN l2.loan_sum
                            ELSE NULL::numeric
                            END)                                                           AS loan_sum_current,
                sum(
                        CASE
                            WHEN c2.check_dt <> (CURRENT_DATE - 1) THEN pay_for_def.amount_cum
                            ELSE NULL::numeric
                            END)                                                           AS amount_cum_generation,
                sum(
                        CASE
                            WHEN c2.check_dt = (CURRENT_DATE - 1) THEN pay_for_def.amount_cum
                            ELSE NULL::numeric
                            END)                                                           AS amount_cum_current,
                count(l2.loan_id)                                                          AS loan_cnt,
                count(pdp.loan_id)                                                         AS cnt_pdp
         FROM loans l2
                  JOIN products p2 ON l2.product_id = p2.product_id
                  LEFT JOIN agents ON agents.loan_id = l2.loan_id
                  LEFT JOIN underwriters un ON un.loan_id = l2.loan_id
                  LEFT JOIN calendar c2 ON 1 = 1 AND date_part('day'::text, c2.check_dt + '1 day'::interval) =
                                                     1::double precision AND
                                           date_trunc('month'::text, l2.loan_issue_date + '03:00:00'::interval)::date <=
                                           date_trunc('month'::text, c2.check_dt + '03:00:00'::interval) OR
                                           c2.check_dt = (CURRENT_DATE - 1)
                  LEFT JOIN pay_for_def
                            ON pay_for_def.loan_id = l2.loan_id AND c2.check_dt = pay_for_def.month_repayment
                  LEFT JOIN pdp ON pdp.loan_id = l2.loan_id AND
                                   pdp.close_mnth = date_trunc('month'::text, c2.check_dt::timestamp with time zone)::date
         WHERE l2.loan_issue_date IS NOT NULL
           AND (l2.product_id = ANY
                (ARRAY ['1d4e88ec-771d-46f9-82c3-edbed1d3a8fa'::uuid, 'fcc45715-bc85-4731-8451-50b0be30962d'::uuid, '25c11318-24fd-40a8-bf35-bb0bd5ac743b'::uuid]))
         GROUP BY c2.check_dt, (date_trunc('month'::text, l2.loan_issue_date + '03:00:00'::interval)::date),
                  (
                      CASE
                          WHEN l2.is_loan_repeated = true THEN 'Повторная'::text
                          ELSE 'Первичная'::text
                          END), p2.product_name, agents.agent_fio, un.underwriter_fio
     ),
     statuses_2 AS (
         SELECT ls.status_id,
                ls.loan_id,
                ls.status_name,
                ls.status_date AS start_status,
                CASE
                    WHEN lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NOT NULL THEN lead(
                                                                                                                  ls.status_date)
                                                                                                                  OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id)
                    WHEN ls.status_name = ANY
                         (ARRAY ['closed'::loansstatusenum, 'closed_overdue'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum, 'cession'::loansstatusenum])
                        THEN ls.status_date::date::timestamp without time zone
                    WHEN lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NULL
                        THEN (CURRENT_DATE + 1)::timestamp without time zone
                    ELSE NULL::timestamp without time zone
                    END        AS stop_status
         FROM loan_statuses ls
                  JOIN loan_statuses_pk_map lspm ON ls.status_id = lspm.pz_id
         WHERE ls.is_deleted IS FALSE
           AND (ls.status_name <> ALL
                (ARRAY ['on_check'::loansstatusenum, 'setting_a_limit'::loansstatusenum, 'pending_issuance_request'::loansstatusenum, 'underwriter_refusal'::loansstatusenum, 'failure_automatic'::loansstatusenum, 'client_refusal'::loansstatusenum, 'loan_approved'::loansstatusenum, 'requesting_loan'::loansstatusenum, 'money_transfer'::loansstatusenum, 'checking_new_client_a'::loansstatusenum, 'checking_repeat_client_a'::loansstatusenum, 'client_definition'::loansstatusenum, 'process_definition'::loansstatusenum, 'ab_test_new'::loansstatusenum, 'checking_new_client_b'::loansstatusenum, 'checking_repeat_client_b'::loansstatusenum, 'ab_test_old'::loansstatusenum, 'checking_new_client'::loansstatusenum, 'checking_repeat_client'::loansstatusenum, 'close_or_extend'::loansstatusenum, 'automatic_check'::loansstatusenum]))
     )
SELECT stage_1.check_dt,
       stage_1.loan_id,
       l.loan_number,
       CASE
           WHEN (l.loan_issue_date + '03:00:00'::interval)::date = stage_1.check_dt THEN l.loan_sum
           ELSE NULL::numeric
           END                                                   AS loan_issuance,
       min(stage_1.check_dt) OVER (PARTITION BY stage_1.loan_id) AS open_dt,
       stage_1.status_name,
       stage_1.status_id_overdue,
       p.product_name,
       CASE
           WHEN l.is_loan_repeated = true THEN 'Повторная'::text
           ELSE 'Первичная'::text
           END                                                   AS is_loan_repeated,
       stage_1.principal_debt,
       stage_1.interest_debt,
       stage_1.service_debt,
       serv.service_sum                                          AS insurance,
       stage_1.loan_in_ca,
       stage_1.amount,
       stage_1.issue_sum_collect,
       CASE
           WHEN stage_1.check_dt >= max(stage_1.check_dt)
                                    FILTER (WHERE stage_1.open_dt_collect IS NOT NULL) OVER (PARTITION BY stage_1.loan_id)
               THEN stage_1.amount
           ELSE NULL::numeric
           END                                                   AS open_dt_collect_pay,
       CASE
           WHEN stage_1.status_name = 'loan_overdue'::loansstatusenum THEN rank()
                                                                           OVER (PARTITION BY stage_1.loan_id, stage_1.status_id_overdue ORDER BY stage_1.check_dt)
           ELSE NULL::bigint
           END                                                   AS day_overdue,
       CASE
           WHEN stage_1.cession_dt = stage_1.check_dt THEN stage_1.principal_debt + stage_1.interest_debt
           ELSE NULL::numeric
           END                                                   AS cession,
       stage_1.cession_dt,
       CASE
           WHEN date_part('day'::text, stage_1.check_dt + '1 day'::interval) = 1::double precision
               THEN stage_1.principal_debt
           ELSE NULL::numeric
           END                                                   AS principal_debt_on_begin_month,
       CASE
           WHEN stage_1.check_dt = (CURRENT_DATE - 1) AND stage_1.status_name = 'loan_overdue'::loansstatusenum
               THEN stage_1.principal_debt
           WHEN stage_1.check_dt = (stage_1.forced_closure_dt - 1) THEN stage_1.principal_debt
           ELSE NULL::numeric
           END                                                   AS overdue_principal_debt_def,
       NULL::numeric                                             AS loan_sum_generation,
       NULL::numeric                                             AS loan_sum_current,
       NULL::numeric                                             AS amount_cum_generation,
       NULL::numeric                                             AS amount_cum_current,
       agents.agent_fio,
       agents.manager_fio,
       agents."group",
       agents.region,
       un.underwriter_fio,
       CASE
           WHEN s2.status_name IS NOT NULL THEN 'Просрочен'::text
           ELSE 'Не просрочен'::text
           END                                                   AS status_on_dt,
       CASE
           WHEN (p.product_name::text = ANY
                 (ARRAY ['Аннуитет'::character varying, 'Аннуитет 2'::character varying, 'Аннуитет 3'::character varying]::text[])) AND
                stage_1.principal_debt = 0::numeric AND
                ((l.loan_issue_date + '03:00:00'::interval)::date + l.loan_period * 7) <> stage_1.check_dt THEN 'ПДП'::text
           ELSE NULL::text
           END                                                   AS full_repayment_flg,
       NULL::bigint                                              AS loan_cnt,
       NULL::numeric                                             AS cum_cnt_pdp
FROM mvw_loan_balances2 stage_1
         LEFT JOIN agents ON agents.loan_id = stage_1.loan_id
         LEFT JOIN underwriters un ON un.loan_id = stage_1.loan_id
         LEFT JOIN loans l ON l.loan_id = stage_1.loan_id
         LEFT JOIN products p ON l.product_id = p.product_id
         LEFT JOIN statuses_2 s2 ON s2.loan_id = stage_1.loan_id AND (stage_1.check_dt + 1) >= s2.start_status AND
                                    (stage_1.check_dt + 1) < s2.stop_status AND s2.status_name = 'loan_overdue'::loansstatusenum
         LEFT JOIN loan_services serv ON serv.loan_id = stage_1.loan_id AND
                                         stage_1.check_dt = (serv.activated_at + '03:00:00'::interval)::date AND
                                         (serv.service_status = ANY
                                          (ARRAY ['service_is_activated'::servicestatusenum, 'service_paid'::servicestatusenum])) AND
                                         serv.service_type = 'extra_service'::servicetypeenum
UNION ALL
SELECT ifd.check_dt,
       NULL::uuid                                                                                                                            AS loan_id,
       NULL::character varying                                                                                                               AS loan_number,
       NULL::numeric                                                                                                                         AS loan_issuance,
       ifd.month_issue                                                                                                                       AS open_dt,
       NULL::loansstatusenum                                                                                                                 AS status_name,
       NULL::text                                                                                                                            AS status_id_overdue,
       ifd.product_name,
       ifd.is_loan_repeated,
       NULL::numeric                                                                                                                         AS principal_debt,
       NULL::numeric                                                                                                                         AS interest_debt,
       NULL::numeric                                                                                                                         AS service_debt,
       NULL::numeric                                                                                                                         AS insurance,
       NULL::text                                                                                                                            AS loan_in_ca,
       NULL::numeric                                                                                                                         AS amount,
       NULL::numeric                                                                                                                         AS issue_sum_collect,
       NULL::numeric                                                                                                                         AS open_dt_collect_pay,
       NULL::bigint                                                                                                                          AS day_overdue,
       NULL::numeric                                                                                                                         AS cession,
       NULL::date                                                                                                                            AS cession_dt,
       NULL::numeric                                                                                                                         AS principal_debt_on_begin_month,
       NULL::numeric                                                                                                                         AS overdue_principal_debt_def,
       ifd.loan_sum_generation,
       ifd.loan_sum_current,
       ifd.amount_cum_generation,
       ifd.amount_cum_current,
       ifd.agent_fio,
       ifd.manager_fio,
       ifd."group",
       ifd.region,
       ifd.underwriter_fio,
       NULL::text                                                                                                                            AS status_on_dt,
       NULL::text                                                                                                                            AS full_repayment_flg,
       ifd.loan_cnt,
       sum(ifd.cnt_pdp)
       OVER (PARTITION BY ifd.agent_fio, ifd.month_issue, ifd.product_name, ifd.is_loan_repeated, ifd.underwriter_fio ORDER BY ifd.check_dt) AS cum_cnt_pdp
FROM issuance_for_default ifd;

alter materialized view mvw_loan_balances_total owner to "pz-zeppelin";

