create materialized view mvw_collection_overdue_debts as
WITH prolongation AS (
    SELECT DISTINCT loan_statuses.loan_id,
                    count(1) OVER (PARTITION BY loan_statuses.loan_id)                                AS cnt_prolong,
                    first_value(loan_statuses.status_date + '03:00:00'::interval)
                    OVER (PARTITION BY loan_statuses.loan_id ORDER BY loan_statuses.status_date DESC) AS last_dt_prolong
    FROM loan_statuses
    WHERE loan_statuses.status_name = 'loan_extended'::loansstatusenum
      AND loan_statuses.is_deleted IS FALSE
),
     comment_ca AS (
         SELECT ct.loan_id,
                a.username,
                ct.created_at,
                ct.task_status,
                ct.comment
         FROM collector_tasks ct
                  JOIN loans l_1 ON ct.loan_id = l_1.loan_id
                  JOIN admins a ON ct.admin_id = a.admin_id AND (a.username::text <> ALL
                                                                 (ARRAY ['admin'::character varying, 'system_user'::character varying, 'Андеррайтер'::character varying]::text[]))
         WHERE ct.comment <> 'Договор передан в коллекторское агентство "ООО «АйДи Коллект»"'::text
     ),
     loan_to_ca AS (
         SELECT ct.loan_id,
                min(
                        CASE
                            WHEN ct.comment = 'Договор передан в коллекторское агентство "ООО «АйДи Коллект»"'::text
                                THEN ct.created_at
                            ELSE NULL::timestamp without time zone
                            END) AS transfer_ca_dt,
                max(
                        CASE
                            WHEN ct.comment = 'Договор отозван из коллекторского агентства "ООО «АйДи Коллект»"'::text
                                THEN ct.created_at
                            ELSE NULL::timestamp without time zone
                            END) AS receive_ca_dt
         FROM collector_tasks ct
                  JOIN loans l_1 ON ct.loan_id = l_1.loan_id
         WHERE ct.comment = ANY
               (ARRAY ['Договор передан в коллекторское агентство "ООО «АйДи Коллект»"'::text, 'Договор отозван из коллекторского агентства "ООО «АйДи Коллект»"'::text])
         GROUP BY ct.loan_id
     ),
     check_period AS (
         SELECT ls.loan_id,
                first_value(ls.status_name)
                OVER (PARTITION BY ls.loan_id ORDER BY ls_pk.sc_id DESC)                             AS last_status_loan,
                first_value(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY ls_pk.sc_id DESC) AS last_status_dt,
                CASE
                    WHEN ls.status_name = 'loan_overdue'::loansstatusenum THEN ls.status_date
                    ELSE NULL::timestamp without time zone
                    END                                                                              AS start_overdue,
                CASE
                    WHEN ls.status_name = 'loan_overdue'::loansstatusenum AND
                         lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY ls_pk.sc_id) IS NOT NULL THEN lead(
                                                                                                                   ls.status_date)
                                                                                                                   OVER (PARTITION BY ls.loan_id ORDER BY ls_pk.sc_id)
                    WHEN ls.status_name = 'loan_overdue'::loansstatusenum AND
                         lead(ls.status_date) OVER (PARTITION BY ls.loan_id ORDER BY ls_pk.sc_id) IS NULL
                        THEN CURRENT_DATE::timestamp without time zone
                    ELSE NULL::timestamp without time zone
                    END                                                                              AS stop_overdue
         FROM loan_statuses ls
                  JOIN loans l_1 USING (loan_id)
                  JOIN loan_statuses_pk_map ls_pk ON ls_pk.pz_id = ls.status_id
         WHERE ls.is_deleted IS FALSE
     )
SELECT DISTINCT ON (l.loan_number, t.history_id) max((t.added_at + '03:00:00'::interval)::date)                              AS pay_dt,
                                                 l.loan_number,
                                                 max(
                                                         CASE
                                                             WHEN cp.last_status_loan::text = 'on_check'::text
                                                                 THEN 'На проверке'::text
                                                             WHEN cp.last_status_loan::text = 'setting_a_limit'::text
                                                                 THEN 'Выставление лимита'::text
                                                             WHEN cp.last_status_loan::text = 'pending_issuance_request'::text
                                                                 THEN 'Ожидание запроса на выдачу'::text
                                                             WHEN cp.last_status_loan::text = 'active_credit'::text
                                                                 THEN 'Активный кредит'::text
                                                             WHEN cp.last_status_loan::text = 'issuance_error'::text
                                                                 THEN 'Ошибка при выдаче'::text
                                                             WHEN cp.last_status_loan::text = 'loan_overdue'::text
                                                                 THEN 'Просрочен'::text
                                                             WHEN cp.last_status_loan::text = 'underwriter_refusal'::text
                                                                 THEN 'Отказ андеррайтера'::text
                                                             WHEN cp.last_status_loan::text = 'failure_automatic'::text
                                                                 THEN 'Отказ автоматический'::text
                                                             WHEN cp.last_status_loan::text = 'client_refusal'::text
                                                                 THEN 'Отказ клиента'::text
                                                             WHEN cp.last_status_loan::text = 'closed'::text
                                                                 THEN 'Закрыт'::text
                                                             WHEN cp.last_status_loan::text = 'closed_overdue'::text
                                                                 THEN 'Закрыт с просрочкой'::text
                                                             WHEN cp.last_status_loan::text = 'frozen_collector'::text
                                                                 THEN 'Заморожен Коллектором'::text
                                                             WHEN cp.last_status_loan::text = 'signing_offer'::text
                                                                 THEN 'Подписание оферты'::text
                                                             WHEN cp.last_status_loan::text = 'loan_approved'::text
                                                                 THEN 'Займ одобрен'::text
                                                             WHEN cp.last_status_loan::text = 'requesting_loan'::text
                                                                 THEN 'Подача заявки на займ'::text
                                                             WHEN cp.last_status_loan::text = 'loan_issued'::text
                                                                 THEN 'Займ выдан'::text
                                                             WHEN cp.last_status_loan::text = 'wrong_form_data'::text
                                                                 THEN 'Заявка заполнена не корректно'::text
                                                             WHEN cp.last_status_loan::text = 'money_transfer'::text
                                                                 THEN 'Перевод денег'::text
                                                             WHEN cp.last_status_loan::text = 'loan_extended'::text
                                                                 THEN 'Займ продлен'::text
                                                             WHEN cp.last_status_loan::text = 'loan_repayment_date'::text
                                                                 THEN 'День погашения займа'::text
                                                             WHEN cp.last_status_loan::text = 'close_or_extend'::text
                                                                 THEN 'Проверка на закрытие или продление займа'::text
                                                             WHEN cp.last_status_loan::text = 'submitted_to_court'::text
                                                                 THEN 'Передано в суд'::text
                                                             WHEN cp.last_status_loan::text = 'automatic_check'::text
                                                                 THEN 'Проверка автоматическая'::text
                                                             WHEN cp.last_status_loan::text = 'period_paid'::text
                                                                 THEN 'Период оплачен'::text
                                                             WHEN cp.last_status_loan::text = 'client_definition'::text
                                                                 THEN 'Определение клиента'::text
                                                             WHEN cp.last_status_loan::text = 'process_definition'::text
                                                                 THEN 'Определение процесса'::text
                                                             WHEN cp.last_status_loan::text = 'checking_new_client_a'::text
                                                                 THEN 'Проверка нового клиента А'::text
                                                             WHEN cp.last_status_loan::text = 'bankrupt'::text
                                                                 THEN 'Банкрот'::text
                                                             WHEN cp.last_status_loan::text = 'checking_repeat_client_a'::text
                                                                 THEN 'Проверка повторного клиента А'::text
                                                             WHEN cp.last_status_loan::text = 'checking_new_client_b'::text
                                                                 THEN 'Проверка нового клиента B'::text
                                                             WHEN cp.last_status_loan::text = 'checking_repeat_client_b'::text
                                                                 THEN 'Проверка повторного клиента B'::text
                                                             WHEN cp.last_status_loan::text = 'ab_test_new'::text
                                                                 THEN 'АБ тест (NEW)'::text
                                                             WHEN cp.last_status_loan::text = 'ab_test_old'::text
                                                                 THEN 'АБ тест (OLD)'::text
                                                             WHEN cp.last_status_loan::text = 'client_died'::text
                                                                 THEN 'Клиент умер'::text
                                                             WHEN cp.last_status_loan::text = 'qiwi_validation'::text
                                                                 THEN 'Идентификация Qiwi'::text
                                                             WHEN cp.last_status_loan::text = 'cession'::text
                                                                 THEN 'Передан по цессии'::text
                                                             WHEN cp.last_status_loan::text = 'checking_new_client'::text
                                                                 THEN 'Проверка нового клиента'::text
                                                             WHEN cp.last_status_loan::text = 'checking_repeat_client'::text
                                                                 THEN 'Проверка повторного клиента'::text
                                                             ELSE cp.last_status_loan::text
                                                             END)                                                            AS last_status_loan,
                                                 max(
                                                         CASE
                                                             WHEN cp.last_status_loan = ANY
                                                                  (ARRAY ['closed'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum, 'cession'::loansstatusenum])
                                                                 THEN cp.last_status_dt + '03:00:00'::interval
                                                             ELSE NULL::timestamp without time zone
                                                             END::date)                                                      AS close_dt,
                                                 max(COALESCE(prolongation.cnt_prolong, 0::bigint))                          AS cnt_prolong,
                                                 max(prolongation.last_dt_prolong::date)                                     AS last_dt_prolong,
                                                 max(
                                                         date_trunc('Month'::text, t.added_at + '03:00:00'::interval)::date) AS pay_month,
                                                 max(
                                                         CASE
                                                             WHEN t.type_record_id = 3 THEN t.record_sum
                                                             ELSE 0::numeric
                                                             END)                                                            AS prolong_sum,
                                                 max(
                                                         CASE
                                                             WHEN t.type_record_id = ANY (ARRAY [2, 5, 7])
                                                                 THEN t.record_sum
                                                             ELSE 0::numeric
                                                             END)                                                            AS close_sum,
                                                 max(
                                                         CASE
                                                             WHEN t.type_record_id = 14 THEN t.record_sum
                                                             ELSE 0::numeric
                                                             END)                                                            AS service_sum,
                                                 max(
                                                         CASE
                                                             WHEN t.type_record_id = 13 THEN t.record_sum
                                                             ELSE 0::numeric
                                                             END)                                                            AS avto_sum,
                                                 max(
                                                         CASE
                                                             WHEN t.type_record_id <> ALL (ARRAY [2, 3, 5, 7, 13, 14])
                                                                 THEN t.record_sum
                                                             ELSE 0::numeric
                                                             END)                                                            AS unknown_sum,
                                                 string_agg(comment_ca.task_status::text, ';'::text)                         AS task_status,
                                                 string_agg(comment_ca.comment, ';'::text)                                   AS comment,
                                                 comment_ca.username,
                                                 comment_ca.created_at,
                                                 max(date_part('day'::text, t.added_at - cp.start_overdue)) +
                                                 1::double precision                                                         AS over_days,
                                                 max(t.added_at::date) - comment_ca.created_at::date                         AS call_and_pay
FROM tmp_account_history t
         JOIN check_period cp
              ON t.loan_id = cp.loan_id AND cp.start_overdue IS NOT NULL AND t.added_at >= cp.start_overdue AND
                 t.added_at <= (cp.stop_overdue::date + 1)
         LEFT JOIN loan_to_ca ON t.loan_id = loan_to_ca.loan_id AND t.added_at >= loan_to_ca.transfer_ca_dt AND
                                 t.added_at <= (loan_to_ca.receive_ca_dt::date + 1)
         LEFT JOIN loan_to_ca loan_to_ca_dt ON t.loan_id = loan_to_ca_dt.loan_id
         LEFT JOIN loans l ON t.loan_id = l.loan_id
         LEFT JOIN comment_ca ON comment_ca.loan_id = cp.loan_id AND comment_ca.created_at >=
                                                                     CASE
                                                                         WHEN cp.start_overdue::date < loan_to_ca_dt.receive_ca_dt::date
                                                                             THEN loan_to_ca_dt.receive_ca_dt::date
                                                                         ELSE cp.start_overdue::date
                                                                         END AND
                                 comment_ca.created_at <= (cp.stop_overdue::date + 1) AND
                                 t.added_at >= comment_ca.created_at AND t.added_at <= (cp.stop_overdue::date + 1)
         LEFT JOIN prolongation ON t.loan_id = prolongation.loan_id
WHERE t.type_record_id <> 1
  AND t.method::text <> 'списание средств с баланса'::text
GROUP BY t.history_id, l.loan_number, comment_ca.username, comment_ca.created_at
ORDER BY l.loan_number, t.history_id, comment_ca.created_at DESC;

alter materialized view mvw_collection_overdue_debts owner to "pz-zeppelin";

