create materialized view mvw_nbki_parse_data_pdn as
WITH loan_x_nbki AS (
    SELECT DISTINCT ON (a.loan_id) a.loan_id,
                                   a.user_id,
                                   a.data_id,
                                   a.requested_at,
                                   a.xml_response,
                                   a.fact
    FROM (SELECT l.loan_id,
                 l.user_id,
                 ns.data_id,
                 ns.requested_at,
                 ns.xml_response,
                 1 AS fact
          FROM loans l
                   JOIN nbki_data ns ON l.loan_id = ns.loan_id
          WHERE l.loan_sum IS NOT NULL
          UNION ALL
          SELECT l.loan_id,
                 l.user_id,
                 ns.data_id,
                 ns.requested_at,
                 ns.xml_response,
                 0 AS fact
          FROM loans l
                   JOIN nbki_data ns
                        ON l.user_id = ns.user_id AND l.loan_date_create > ns.requested_at AND l.loan_id <> ns.loan_id
          WHERE l.loan_sum IS NOT NULL) a
    ORDER BY a.loan_id, a.fact DESC, a.requested_at DESC
),
     pre_data AS (
         SELECT lxn.loan_id,
                lxn.user_id,
                lxn.data_id,
                lxn.requested_at,
                lxn.xml_response,
                lxn.fact,
                unnest(xpath('//AccountReply'::text, XMLPARSE(DOCUMENT lxn.xml_response STRIP WHITESPACE))) AS x
         FROM loan_x_nbki lxn
                  JOIN loans l2 ON l2.loan_id = lxn.loan_id
     )
SELECT pre_data.loan_id,
       pre_data.user_id,
       pre_data.data_id,
       pre_data.requested_at,
       (xpath('//accountRatingText/text()'::text, pre_data.x))[1]::character varying             AS account_rating,
       (xpath('//acctTypeText/text()'::text, pre_data.x))[1]::character varying                  AS account_type_text,
       (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer             AS accttype,
       (xpath('//creditLimit/text()'::text, pre_data.x))[1]::character varying::integer          AS creditlimit,
       (xpath('//uuid/text()'::text, pre_data.x))[1]::character varying                          AS uuid_bki,
       CASE
           WHEN replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                        '.'::text) ~ '^\d+\.?\d+$'::text THEN replace(
                   (xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                   '.'::text)::numeric(20, 3)
           ELSE NULL::numeric
           END                                                                                   AS pti,
       (xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date                AS openeddt,
       (xpath('//closedDt/text()'::text, pre_data.x))[1]::character varying::date                AS closeddt,
       (xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date          AS paymentduedate,
       (xpath('//principalOutstanding/text()'::text, pre_data.x))[1]::character varying::integer AS principaloutstanding,
       (xpath('//amtOutstanding/text()'::text, pre_data.x))[1]::character varying::integer       AS amtoutstanding,
       (xpath('//principalPastDue/text()'::text, pre_data.x))[1]::character varying::integer     AS principalpastdue,
       (xpath('//intPastDue/text()'::text, pre_data.x))[1]::character varying::integer           AS intpastdue,
       (xpath('//intOutstanding/text()'::text, pre_data.x))[1]::character varying::integer       AS intoutstanding,
       (xpath('//otherAmtOutstanding/text()'::text, pre_data.x))[1]::character varying::integer  AS otheramtoutstanding,
       (xpath('//otherAmtPastDue/text()'::text, pre_data.x))[1]::character varying::integer      AS otheramtpastdue,
       (xpath('//amtPastDue/text()'::text, pre_data.x))[1]::character varying::integer           AS amtpastdue,
       CASE
           WHEN (xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date >
                ((pre_data.requested_at + '03:00:00'::interval)::date + 30) THEN ceil(
                       ((xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date -
                        (pre_data.requested_at + '03:00:00'::interval)::date)::double precision / 30::double precision)
           ELSE 1::double precision
           END                                                                                   AS term,
       CASE
           WHEN (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 16 AND
                (xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date <=
                ((xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date + 30) AND
                (((xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date -
                  (xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date)::double precision /
                 30::double precision) >= 0::double precision THEN
                   ((xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date -
                    (xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date)::double precision /
                   30::double precision
           ELSE 1::double precision
           END                                                                                   AS popr,
       CASE
           WHEN (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 16 AND
                (xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date <=
                ((xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date + 30) AND
                (((xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date -
                  (xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date)::double precision /
                 30::double precision) >= 1::double precision THEN
                   ((xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date -
                    (xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date)::double precision /
                   30::double precision
           ELSE 1::double precision
           END                                                                                   AS popr2,
       CASE
           WHEN (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 16 AND
                (xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date <=
                ((xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date + 30) THEN
                   ((xpath('//paymentDueDate/text()'::text, pre_data.x))[1]::character varying::date -
                    (xpath('//openedDt/text()'::text, pre_data.x))[1]::character varying::date)::double precision /
                   30::double precision
           ELSE 1::double precision
           END                                                                                   AS popr3,
       CASE
           WHEN (xpath('//principalOutstanding/text()'::text, pre_data.x))[1]::character varying::integer IS NOT NULL
               THEN (xpath('//principalOutstanding/text()'::text, pre_data.x))[1]::character varying::integer
           WHEN (xpath('//amtOutstanding/text()'::text, pre_data.x))[1]::character varying::integer > 0 THEN LEAST(
                   (xpath('//amtOutstanding/text()'::text, pre_data.x))[1]::character varying::integer,
                   (xpath('//creditLimit/text()'::text, pre_data.x))[1]::character varying::integer)
           ELSE (xpath('//creditLimit/text()'::text, pre_data.x))[1]::character varying::integer
           END                                                                                   AS principaloutstanding_mod,
       CASE
           WHEN (xpath('//currencyCode/text()'::text, pre_data.x))[1]::character varying::text = 'RUB'::text THEN 1::numeric
           WHEN (xpath('//currencyCode/text()'::text, pre_data.x))[1]::character varying::text = 'USD'::text THEN 62.5
           WHEN (xpath('//currencyCode/text()'::text, pre_data.x))[1]::character varying::text = 'EUR'::text THEN 69.5
           ELSE 1::numeric
           END                                                                                   AS currencyrate,
       (xpath('//currencyCode/text()'::text, pre_data.x))[1]::character varying                  AS currencycode,
       CASE
           WHEN replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                        '.'::text) ~ '^\d+\.?\d+$'::text AND
                replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                        '.'::text)::numeric(20, 3) > 0::numeric AND
                replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                        '.'::text)::numeric(20, 3) < 1000::numeric THEN
                   replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                           '.'::text)::numeric(20, 3) / 100::numeric
           WHEN (NOT replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text,
                             ','::text, '.'::text) ~ '^\d+\.?\d+$'::text OR
                 replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                         '.'::text)::numeric(20, 3) = 0::numeric) AND
                (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 16 THEN 3.65
           WHEN (NOT replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text,
                             ','::text, '.'::text) ~ '^\d+\.?\d+$'::text OR
                 replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                         '.'::text)::numeric(20, 3) = 0::numeric) AND
                (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 1 THEN 0.20
           WHEN (NOT replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text,
                             ','::text, '.'::text) ~ '^\d+\.?\d+$'::text OR
                 replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                         '.'::text)::numeric(20, 3) = 0::numeric) AND
                (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 6 THEN 0.12
           WHEN (NOT replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text,
                             ','::text, '.'::text) ~ '^\d+\.?\d+$'::text OR
                 replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                         '.'::text)::numeric(20, 3) = 0::numeric) AND
                (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 9 THEN 0.35
           WHEN (NOT replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text,
                             ','::text, '.'::text) ~ '^\d+\.?\d+$'::text OR
                 replace((xpath('//creditTotalAmt/text()'::text, pre_data.x))[1]::character varying::text, ','::text,
                         '.'::text)::numeric(20, 3) = 0::numeric) AND
                (xpath('//acctType/text()'::text, pre_data.x))[1]::character varying::integer = 7 THEN 0.25
           ELSE 0.35
           END                                                                                   AS rate
FROM pre_data
WHERE 1 = 1
  AND ((xpath('//accountRating/text()'::text, pre_data.x))[1]::character varying::integer <> ALL (ARRAY [13, 14]))
  AND (((pre_data.requested_at + '03:00:00'::interval)::date -
        (xpath('//lastUpdatedDt/text()'::text, pre_data.x))[1]::character varying::date) < 730 OR
       (xpath('//amtPastDue/text()'::text, pre_data.x))[1]::character varying::integer > 0 OR
       (COALESCE((xpath('//otherAmtOutstanding/text()'::text, pre_data.x))[1]::character varying::integer, 0) +
        COALESCE((xpath('//principalPastDue/text()'::text, pre_data.x))[1]::character varying::integer, 0) +
        COALESCE((xpath('//intPastDue/text()'::text, pre_data.x))[1]::character varying::integer, 0)) > 0)
  AND (pre_data.requested_at + '03:00:00'::interval) > '2022-03-01 00:00:00'::timestamp without time zone;

alter materialized view mvw_nbki_parse_data_pdn owner to "pz-zeppelin";

