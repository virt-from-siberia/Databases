create materialized view mvw_aggregated_balance as
WITH calendar AS (
    SELECT generate_series('2020-08-01 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '1 mon'::interval)::date AS cldr_period
),
     issuing_loans AS (
         SELECT date_trunc('month'::text, l.loan_issue_date + '03:00:00'::interval)::date AS value_period,
                l.is_loan_repeated,
                p.product_name,
                - sum(l.loan_sum)                                                         AS value,
                '1. Выдача'::text                                                         AS value_type
         FROM loans l
                  JOIN products p ON p.product_id = l.product_id
         WHERE l.loan_issue_date IS NOT NULL
         GROUP BY (date_trunc('month'::text, l.loan_issue_date + '03:00:00'::interval)), l.is_loan_repeated,
                  p.product_name
     ),
     loan_receipts AS (
         SELECT date_trunc('month'::text, init_data.added_at + '03:00:00'::interval)::date AS value_period,
                l.is_loan_repeated,
                p.product_name,
                sum(init_data.loan_repayment)                                              AS loan_repayment,
                sum(init_data.interest_repayment)                                          AS interest_repayment
         FROM (SELECT d.added_at,
                      d.loan_id,
                      lag(d.principal_debt) OVER (PARTITION BY d.loan_id ORDER BY dpm.sc_id) -
                      d.principal_debt                                                                        AS loan_repayment,
                      lag(d.interest_debt) OVER (PARTITION BY d.loan_id ORDER BY dpm.sc_id) -
                      d.interest_debt                                                                         AS interest_repayment
               FROM debt d
                        JOIN debt_pk_map dpm ON d.debt_id = dpm.pz_id) init_data
                  JOIN loans l ON l.loan_id = init_data.loan_id
                  JOIN products p ON p.product_id = l.product_id
         WHERE init_data.interest_repayment >= 0::numeric
         GROUP BY (date_trunc('month'::text, init_data.added_at + '03:00:00'::interval)::date), l.is_loan_repeated,
                  p.product_name
     ),
     service_payments AS (
         WITH serv_pay AS (
             SELECT DISTINCT ON (l.loan_id, services.service_type) date_trunc('month'::text, t.trans_date + '03:00:00'::interval)::date AS value_period,
                                                                   l.is_loan_repeated,
                                                                   p.product_name,
                                                                   CASE
                                                                       WHEN services.service_type = 'extra_service'::servicetypeenum
                                                                           THEN '2. Доходы. Доп.услуга - Страховка'::text
                                                                       WHEN services.service_type =
                                                                            'payment_service_accelerated_review'::servicetypeenum
                                                                           THEN '2. Доходы. Доп.услуга - Комиссия'::text
                                                                       ELSE '2. Доходы. Доп.услуга - сервис не определен'::text
                                                                       END                                                              AS value_type,
                                                                   services.service_sum,
                                                                   t.amount,
                                                                   l.loan_sum,
                                                                   sum(t.amount)
                                                                   FILTER (WHERE services.service_type = 'extra_service'::servicetypeenum) OVER (PARTITION BY l.loan_number ORDER BY (t.trans_date + '03:00:00'::interval)) >=
                                                                   services.service_sum                                                 AS flg_full_pay
             FROM transactions t
                      JOIN loans l ON t.loan_id = l.loan_id
                      JOIN products p ON p.product_id = l.product_id
                      LEFT JOIN transaction_to_service tts ON tts.transaction_id = t.trans_id
                      LEFT JOIN loan_services services ON tts.service_id = services.service_id
             WHERE t.trans_type = 'payment_for_service'::transtypeenum
             ORDER BY l.loan_id, services.service_type, t.trans_date DESC
         )
         SELECT serv_pay.value_period,
                serv_pay.is_loan_repeated,
                serv_pay.product_name,
                serv_pay.value_type,
                sum(serv_pay.amount) AS value
         FROM serv_pay
         GROUP BY serv_pay.value_period, serv_pay.is_loan_repeated, serv_pay.product_name, serv_pay.value_type
         UNION ALL
         SELECT serv_pay.value_period,
                serv_pay.is_loan_repeated,
                serv_pay.product_name,
                '1. Расходы. Страховая премия'::text AS value_type,
                - sum(
                        CASE
                            WHEN serv_pay.product_name::text = ANY
                                 (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[]) THEN 75
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 31000::numeric AND serv_pay.loan_sum < 41000::numeric THEN 600
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 41000::numeric AND serv_pay.loan_sum < 51000::numeric THEN 750
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 51000::numeric AND serv_pay.loan_sum < 61000::numeric THEN 900
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 61000::numeric AND serv_pay.loan_sum < 71000::numeric THEN 1050
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 71000::numeric AND serv_pay.loan_sum < 81000::numeric THEN 1200
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 81000::numeric AND serv_pay.loan_sum < 91000::numeric THEN 1350
                            WHEN serv_pay.product_name::text = 'Аннуитет'::text AND
                                 serv_pay.loan_sum >= 91000::numeric AND serv_pay.loan_sum <= 100000::numeric THEN 1500
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 20000::numeric AND serv_pay.loan_sum < 21000::numeric THEN 200
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 21000::numeric AND serv_pay.loan_sum < 31000::numeric THEN 300
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 31000::numeric AND serv_pay.loan_sum < 41000::numeric THEN 400
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 41000::numeric AND serv_pay.loan_sum < 51000::numeric THEN 500
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 51000::numeric AND serv_pay.loan_sum < 61000::numeric THEN 600
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 61000::numeric AND serv_pay.loan_sum < 71000::numeric THEN 700
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 71000::numeric AND serv_pay.loan_sum < 81000::numeric THEN 800
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 81000::numeric AND serv_pay.loan_sum < 91000::numeric THEN 900
                            WHEN serv_pay.product_name::text = 'Аннуитет 2'::text AND
                                 serv_pay.loan_sum >= 91000::numeric AND serv_pay.loan_sum <= 100000::numeric THEN 1000
                            WHEN serv_pay.product_name::text = 'Аннуитет 3'::text AND
                                 serv_pay.loan_sum >= 20000::numeric AND serv_pay.loan_sum < 31000::numeric THEN 300
                            WHEN serv_pay.product_name::text = 'Аннуитет 3'::text AND
                                 serv_pay.loan_sum >= 31000::numeric AND serv_pay.loan_sum < 41000::numeric THEN 600
                            WHEN serv_pay.product_name::text = 'Аннуитет 3'::text AND
                                 serv_pay.loan_sum >= 41000::numeric AND serv_pay.loan_sum < 51000::numeric THEN 750
                            ELSE 0
                            END)                     AS value
         FROM serv_pay
         WHERE serv_pay.flg_full_pay IS TRUE
         GROUP BY serv_pay.value_period, serv_pay.is_loan_repeated, serv_pay.product_name
     ),
     application AS (
         SELECT date_trunc('month'::text, init_data.check_dt)::date                  AS value_period,
                init_data.is_loan_repeated,
                init_data.product_name,
                CASE
                    WHEN max(init_data.idx_cnt_month) <= 1000 THEN count(
                                                                           CASE
                                                                               WHEN (init_data.product_name::text = ANY
                                                                                     (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])) AND
                                                                                    init_data.is_loan_repeated IS FALSE
                                                                                   THEN init_data.check_dt
                                                                               ELSE NULL::timestamp without time zone
                                                                               END) * 10
                    WHEN max(init_data.idx_cnt_month) > 1000 AND max(init_data.idx_cnt_month) <= 10000 AND
                         init_data.is_loan_repeated IS FALSE THEN count(
                                                                          CASE
                                                                              WHEN init_data.product_name::text = ANY
                                                                                   (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                  THEN init_data.check_dt
                                                                              ELSE NULL::timestamp without time zone
                                                                              END) * 7
                    WHEN max(init_data.idx_cnt_month) > 10000 AND max(init_data.idx_cnt_month) <= 50000 AND
                         init_data.is_loan_repeated IS FALSE THEN count(
                                                                          CASE
                                                                              WHEN init_data.product_name::text = ANY
                                                                                   (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                  THEN init_data.check_dt
                                                                              ELSE NULL::timestamp without time zone
                                                                              END) * 6
                    WHEN max(init_data.idx_cnt_month) > 50000 AND init_data.is_loan_repeated IS FALSE THEN count(
                                                                                                                   CASE
                                                                                                                       WHEN init_data.product_name::text = ANY
                                                                                                                            (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                                                           THEN init_data.check_dt
                                                                                                                       ELSE NULL::timestamp without time zone
                                                                                                                       END) *
                                                                                                           5
                    ELSE NULL::bigint
                    END                                                              AS value1,
                CASE
                    WHEN max(init_data.infosf_cnt_month) < 10000 AND init_data.is_loan_repeated IS FALSE THEN count(
                                                                                                                      CASE
                                                                                                                          WHEN init_data.product_name::text <> ALL
                                                                                                                               (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                                                              THEN init_data.check_dt
                                                                                                                          ELSE NULL::timestamp without time zone
                                                                                                                          END)::numeric *
                                                                                                              1.5
                    WHEN max(init_data.infosf_cnt_month) >= 10000 AND max(init_data.infosf_cnt_month) < 25000 AND
                         init_data.is_loan_repeated IS FALSE THEN (count(
                                                                           CASE
                                                                               WHEN init_data.product_name::text <> ALL
                                                                                    (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                   THEN init_data.check_dt
                                                                               ELSE NULL::timestamp without time zone
                                                                               END) * 1)::numeric
                    WHEN max(init_data.infosf_cnt_month) >= 25000 AND max(init_data.infosf_cnt_month) < 50000 AND
                         init_data.is_loan_repeated IS FALSE THEN count(
                                                                          CASE
                                                                              WHEN init_data.product_name::text <> ALL
                                                                                   (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                  THEN init_data.check_dt
                                                                              ELSE NULL::timestamp without time zone
                                                                              END)::numeric * 0.9
                    WHEN max(init_data.infosf_cnt_month) >= 50000 AND max(init_data.infosf_cnt_month) < 100000 AND
                         init_data.is_loan_repeated IS FALSE THEN count(
                                                                          CASE
                                                                              WHEN init_data.product_name::text <> ALL
                                                                                   (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                  THEN init_data.check_dt
                                                                              ELSE NULL::timestamp without time zone
                                                                              END)::numeric * 0.8
                    WHEN max(init_data.infosf_cnt_month) >= 100000 AND max(init_data.infosf_cnt_month) < 250000 AND
                         init_data.is_loan_repeated IS FALSE THEN count(
                                                                          CASE
                                                                              WHEN init_data.product_name::text <> ALL
                                                                                   (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])
                                                                                  THEN init_data.check_dt
                                                                              ELSE NULL::timestamp without time zone
                                                                              END)::numeric * 0.7
                    ELSE NULL::numeric
                    END                                                              AS value2,
                count(init_data.check_dt) * 20000 / max(init_data.bankrot_cnt_month) AS value3
         FROM (SELECT l.loan_id,
                      l.loan_date_create + '03:00:00'::interval                                                                                                              AS check_dt,
                      l.is_loan_repeated,
                      p.product_name,
                      count(l.loan_id) FILTER (WHERE (p.product_name::text = ANY
                                                      (ARRAY ['PDL'::character varying, 'промопродукт'::character varying]::text[])) AND
                                                     l.is_loan_repeated IS FALSE) OVER (PARTITION BY (date_trunc('month'::text, l.loan_date_create + '03:00:00'::interval))) AS idx_cnt_month,
                      count(l.loan_id)
                      FILTER (WHERE l.is_loan_repeated IS FALSE) OVER (PARTITION BY (date_trunc('month'::text, l.loan_date_create + '03:00:00'::interval)))                  AS infosf_cnt_month,
                      count(l.loan_id)
                      OVER (PARTITION BY (date_trunc('month'::text, l.loan_date_create + '03:00:00'::interval)))                                                             AS bankrot_cnt_month
               FROM loans l
                        JOIN products p ON p.product_id = l.product_id) init_data
         GROUP BY (date_trunc('month'::text, init_data.check_dt)::date), init_data.is_loan_repeated,
                  init_data.product_name
     ),
     credit_history AS (
         SELECT date_trunc('month'::text, npd.requested_at + '03:00:00'::interval)::date AS value_period,
                l2.is_loan_repeated,
                p.product_name,
                CASE
                    WHEN max(mnth_data.cnt_mnth_ki) <= 2500 THEN count(npd.data_id)::numeric * 22.4
                    WHEN max(mnth_data.cnt_mnth_ki) > 2500 AND max(mnth_data.cnt_mnth_ki) <= 5000
                        THEN count(npd.data_id)::numeric * 22.18
                    WHEN max(mnth_data.cnt_mnth_ki) > 5000 AND max(mnth_data.cnt_mnth_ki) <= 10000
                        THEN count(npd.data_id)::numeric * 21.28
                    WHEN max(mnth_data.cnt_mnth_ki) > 10000 AND max(mnth_data.cnt_mnth_ki) <= 30000
                        THEN count(npd.data_id)::numeric * 19.60
                    WHEN max(mnth_data.cnt_mnth_ki) > 30000 AND max(mnth_data.cnt_mnth_ki) <= 60000
                        THEN count(npd.data_id)::numeric * 17.36
                    WHEN max(mnth_data.cnt_mnth_ki) > 60000 AND max(mnth_data.cnt_mnth_ki) <= 90000
                        THEN count(npd.data_id)::numeric * 15.57
                    WHEN max(mnth_data.cnt_mnth_ki) > 90000 AND max(mnth_data.cnt_mnth_ki) <= 130000
                        THEN count(npd.data_id)::numeric * 13.66
                    WHEN max(mnth_data.cnt_mnth_ki) > 130000 AND max(mnth_data.cnt_mnth_ki) <= 250000
                        THEN count(npd.data_id)::numeric * 11.54
                    ELSE NULL::numeric
                    END                                                                  AS value1,
                CASE
                    WHEN max(mnth_data.cnt_mnth_scor) <= 10000 THEN count(npd.score) * 15
                    WHEN max(mnth_data.cnt_mnth_scor) > 10000 AND max(mnth_data.cnt_mnth_scor) <= 50000
                        THEN count(npd.score) * 13
                    WHEN max(mnth_data.cnt_mnth_scor) > 50000 AND max(mnth_data.cnt_mnth_scor) <= 100000
                        THEN count(npd.score) * 12
                    WHEN max(mnth_data.cnt_mnth_scor) > 100000 AND max(mnth_data.cnt_mnth_scor) <= 200000
                        THEN count(npd.score) * 10
                    ELSE NULL::bigint
                    END                                                                  AS value2
         FROM nbki_parsed_data npd
                  JOIN loans l2 ON l2.loan_id = npd.loan_id
                  JOIN products p ON p.product_id = l2.product_id
                  JOIN (SELECT date_trunc('month'::text, npd2.requested_at + '03:00:00'::interval)::date AS mnth_req,
                               count(npd2.data_id)                                                       AS cnt_mnth_ki,
                               count(npd2.score)                                                         AS cnt_mnth_scor
                        FROM nbki_parsed_data npd2
                        GROUP BY (date_trunc('month'::text, npd2.requested_at + '03:00:00'::interval)::date)) mnth_data
                       ON mnth_data.mnth_req = date_trunc('month'::text, npd.requested_at + '03:00:00'::interval)::date
         GROUP BY (date_trunc('month'::text, npd.requested_at + '03:00:00'::interval)::date), l2.is_loan_repeated,
                  p.product_name
     ),
     acquiring AS (
         SELECT date_trunc('month'::text, t.trans_date + '03:00:00'::interval)::date AS value_period,
                l3.is_loan_repeated,
                p2.product_name,
                sum(round(
                        CASE
                            WHEN t.trans_method = 'tinkoff'::transmethodenum AND
                                 ((t.trans_date + '03:00:00'::interval)::date -
                                  (l3.loan_issue_date + '03:00:00'::interval)::date) <= 5 AND
                                 t.trans_type = 'early_repayment'::transtypeenum THEN t.amount * 0.01
                            ELSE NULL::numeric
                            END, 2))                                                 AS value1,
                sum(round(
                        CASE
                            WHEN t.trans_method = 'tinkoff'::transmethodenum AND
                                 t.trans_type = 'loan_issuance'::transtypeenum AND (- t.amount) >= 4300::numeric
                                THEN (- t.amount) * 0.007
                            WHEN t.trans_method = 'tinkoff'::transmethodenum AND
                                 t.trans_type = 'loan_issuance'::transtypeenum AND (- t.amount) < 4300::numeric THEN 30::numeric
                            WHEN t.trans_method = 'tinkoff'::transmethodenum AND
                                 NOT (((t.trans_date + '03:00:00'::interval)::date -
                                       (l3.loan_issue_date + '03:00:00'::interval)::date) <= 5 AND
                                      t.trans_type = 'early_repayment'::transtypeenum) AND
                                 t.trans_type <> 'loan_issuance'::transtypeenum AND t.amount >= 4300::numeric
                                THEN t.amount * 0.006
                            WHEN t.trans_method = 'tinkoff'::transmethodenum AND
                                 NOT (((t.trans_date + '03:00:00'::interval)::date -
                                       (l3.loan_issue_date + '03:00:00'::interval)::date) <= 5 AND
                                      t.trans_type = 'early_repayment'::transtypeenum) AND
                                 t.trans_type <> 'loan_issuance'::transtypeenum AND t.amount < 4300::numeric THEN 30::numeric
                            ELSE NULL::numeric
                            END, 2))                                                 AS value2,
                sum(round(
                        CASE
                            WHEN (t.trans_method = ANY
                                  (ARRAY ['mandarinpay'::transmethodenum, 'payoff'::transmethodenum])) AND
                                 t.trans_type = 'loan_issuance'::transtypeenum AND (- t.amount) >= 1250::numeric
                                THEN (- t.amount) * 0.007
                            WHEN (t.trans_method = ANY
                                  (ARRAY ['mandarinpay'::transmethodenum, 'payoff'::transmethodenum])) AND
                                 t.trans_type = 'loan_issuance'::transtypeenum AND (- t.amount) < 1250::numeric THEN 30::numeric
                            WHEN (t.trans_method = ANY
                                  (ARRAY ['mandarinpay'::transmethodenum, 'payoff'::transmethodenum])) AND
                                 t.trans_type <> 'loan_issuance'::transtypeenum AND t.amount >= 1250::numeric
                                THEN t.amount * 0.007
                            WHEN (t.trans_method = ANY
                                  (ARRAY ['mandarinpay'::transmethodenum, 'payoff'::transmethodenum])) AND
                                 t.trans_type <> 'loan_issuance'::transtypeenum AND t.amount < 1250::numeric THEN 30::numeric
                            ELSE NULL::numeric
                            END, 2))                                                 AS value3,
                sum(round(
                        CASE
                            WHEN (t.trans_method = ANY
                                  (ARRAY ['cash'::transmethodenum, 'cashless_payment'::transmethodenum, 'unknown'::transmethodenum])) AND
                                 t.amount > 0::numeric THEN t.amount * 0.017
                            ELSE NULL::numeric
                            END, 2))                                                 AS value4
         FROM transactions t
                  JOIN loans l3 ON l3.loan_id = t.loan_id
                  JOIN products p2 ON p2.product_id = l3.product_id
         GROUP BY (date_trunc('month'::text, t.trans_date + '03:00:00'::interval)::date), l3.is_loan_repeated,
                  p2.product_name
     ),
     motivation_agents AS (
         WITH for_issuing AS (
             SELECT date_trunc('month'::text, l4.loan_issue_date + '03:00:00'::interval)::date AS value_period,
                    l4.is_loan_repeated,
                    p3.product_name,
                    CASE
                        WHEN count(l4.loan_id) OVER (PARTITION BY l4.user_id ORDER BY l4.loan_issue_date) = 1 THEN 3000
                        ELSE 1000
                        END                                                                    AS value
             FROM loans l4
                      JOIN products p3 ON p3.product_id = l4.product_id AND (p3.product_name::text = ANY
                                                                             (ARRAY ['Аннуитет'::character varying, 'Аннуитет 2'::character varying, 'Аннуитет 3'::character varying]::text[]))
             WHERE l4.loan_issue_date IS NOT NULL
         )
         SELECT date_trunc('month'::text, t2.trans_date + '03:00:00'::interval)::date AS value_period,
                l5.is_loan_repeated,
                p4.product_name,
                (- sum(t2.amount)) * 0.1                                              AS value,
                '1. Расходы. Премия за сбор по Install'::text                         AS value_type
         FROM transactions t2
                  JOIN loans l5 ON l5.loan_id = t2.loan_id
                  JOIN products p4 ON p4.product_id = l5.product_id AND (p4.product_name::text = ANY
                                                                         (ARRAY ['Аннуитет'::character varying, 'Аннуитет 2'::character varying, 'Аннуитет 3'::character varying]::text[]))
         WHERE t2.amount > 0::numeric
         GROUP BY (date_trunc('month'::text, t2.trans_date + '03:00:00'::interval)::date), l5.is_loan_repeated,
                  p4.product_name
         UNION ALL
         SELECT fi.value_period,
                fi.is_loan_repeated,
                fi.product_name,
                - sum(fi.value)                              AS value,
                '1. Расходы. Премия за выдачу Install'::text AS value_type
         FROM for_issuing fi
         GROUP BY fi.value_period, fi.is_loan_repeated, fi.product_name
     ),
     cession AS (
         SELECT date_trunc('month'::text, init_data.status_date)::date AS value_period,
                init_data.is_loan_repeated,
                init_data.product_name,
                sum(init_data.komiss_cession)                          AS komiss_cession
         FROM (SELECT DISTINCT ON (ls.loan_id) l6.is_loan_repeated,
                                               p5.product_name,
                                               ls.status_date + '03:00:00'::interval AS status_date,
                                               round(
                                                       CASE
                                                           WHEN (ls.status_date + '03:00:00'::interval)::date < '2021-09-10'::date
                                                               THEN d.total_debt * 0.49
                                                           WHEN (ls.status_date + '03:00:00'::interval)::date >= '2021-11-14'::date AND
                                                                (ls.status_date + '03:00:00'::interval)::date < '2021-12-03'::date
                                                               THEN d.total_debt * 0.3
                                                           WHEN (ls.status_date + '03:00:00'::interval)::date >= '2021-12-26'::date
                                                               THEN d.total_debt * 0.33
                                                           ELSE NULL::numeric
                                                           END, 2)                   AS komiss_cession
               FROM loan_statuses ls
                        JOIN loans l6 ON l6.loan_id = ls.loan_id
                        JOIN products p5 ON p5.product_id = l6.product_id
                        JOIN debt d ON d.loan_id = ls.loan_id AND d.added_at < ls.status_date AND
                                       d.added_at > (ls.status_date::date - 2) AND d.total_debt > 0::numeric
               WHERE ls.is_deleted IS FALSE
                 AND ls.status_name = 'cession'::loansstatusenum
               ORDER BY ls.loan_id, d.added_at DESC) init_data
         GROUP BY (date_trunc('month'::text, init_data.status_date)::date), init_data.is_loan_repeated,
                  init_data.product_name
     )
SELECT c.cldr_period,
       il.is_loan_repeated,
       il.product_name,
       il.value,
       il.value_type
FROM calendar c
         LEFT JOIN issuing_loans il ON il.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       lr1.is_loan_repeated,
       lr1.product_name,
       lr1.loan_repayment              AS value,
       '2. Доходы. Погашение ОД'::text AS value_type
FROM calendar c
         LEFT JOIN loan_receipts lr1 ON lr1.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       lr2.is_loan_repeated,
       lr2.product_name,
       lr2.interest_repayment          AS value,
       '2. Доходы. Погашение %%'::text AS value_type
FROM calendar c
         LEFT JOIN loan_receipts lr2 ON lr2.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       sp.is_loan_repeated,
       sp.product_name,
       sp.value,
       sp.value_type
FROM calendar c
         LEFT JOIN service_payments sp ON sp.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       a1.is_loan_repeated,
       a1.product_name,
       - a1.value1               AS value,
       '1. Расходы по IDX'::text AS value_type
FROM calendar c
         LEFT JOIN application a1 ON a1.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       a2.is_loan_repeated,
       a2.product_name,
       - a2.value2                     AS value,
       '1. Расходы по Инфосфера'::text AS value_type
FROM calendar c
         LEFT JOIN application a2 ON a2.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       a3.is_loan_repeated,
       a3.product_name,
       - a3.value3                     AS value,
       '1. Расходы по Банкротам'::text AS value_type
FROM calendar c
         LEFT JOIN application a3 ON a3.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       ch1.is_loan_repeated,
       ch1.product_name,
       - ch1.value1                           AS value,
       '1. Расходы по НБКИ. Отчет о КИ'::text AS value_type
FROM calendar c
         LEFT JOIN credit_history ch1 ON ch1.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       ch2.is_loan_repeated,
       ch2.product_name,
       - ch2.value2                        AS value,
       '1. Расходы по НБКИ. Скоринг'::text AS value_type
FROM calendar c
         LEFT JOIN credit_history ch2 ON ch2.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       aq1.is_loan_repeated,
       aq1.product_name,
       aq1.value1                                AS value,
       '2. Доход от эквайринга (Тинькофф)'::text AS value_type
FROM calendar c
         LEFT JOIN acquiring aq1 ON aq1.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       aq2.is_loan_repeated,
       aq2.product_name,
       - aq2.value2                                AS value,
       '1. Расходы по эквайрингу (Тинькофф)'::text AS value_type
FROM calendar c
         LEFT JOIN acquiring aq2 ON aq2.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       aq3.is_loan_repeated,
       aq3.product_name,
       - aq3.value3                                AS value,
       '1. Расходы по эквайрингу (Мандарин)'::text AS value_type
FROM calendar c
         LEFT JOIN acquiring aq3 ON aq3.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       aq4.is_loan_repeated,
       aq4.product_name,
       - aq4.value4                       AS value,
       '1. Расходы по Почте России'::text AS value_type
FROM calendar c
         LEFT JOIN acquiring aq4 ON aq4.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       ma.is_loan_repeated,
       ma.product_name,
       ma.value,
       ma.value_type
FROM calendar c
         LEFT JOIN motivation_agents ma ON ma.value_period = c.cldr_period
UNION ALL
SELECT c.cldr_period,
       cession.is_loan_repeated,
       cession.product_name,
       cession.komiss_cession                AS value,
       '2. Доходы. Комиссия за цессию'::text AS value_type
FROM calendar c
         LEFT JOIN cession ON cession.value_period = c.cldr_period;

alter materialized view mvw_aggregated_balance owner to "pz-zeppelin";

