create materialized view mvw_plan_fact_events as
WITH calendar AS (
    SELECT generate_series('2020-08-01 00:00:00'::timestamp without time zone,
                           CURRENT_DATE::timestamp without time zone, '1 day'::interval)::date AS check_dt
),
     pdl_plan_close AS (
         SELECT l_1.loan_id,
                (l_1.loan_issue_date + '03:00:00'::interval)::date                   AS start_period,
                (l_1.loan_issue_date + '03:00:00'::interval)::date + l_1.loan_period AS stop_period,
                p.product_name
         FROM loans l_1
                  JOIN products p ON l_1.product_id = p.product_id
         UNION ALL
         SELECT lp.loan_id,
                (lp.added_at + '03:00:00'::interval)::date             AS start_period,
                (lp.added_at + '03:00:00'::interval)::date + lp.period AS stop_period,
                p.product_name
         FROM loan_prolongations lp
                  JOIN loans l_1 ON l_1.loan_id = lp.loan_id
                  JOIN products p ON l_1.product_id = p.product_id
     ),
     statuses AS (
         SELECT init_data.loan_id,
                init_data.status_name,
                init_data.start_stat::date AS start_stat,
                init_data.product_name
         FROM (SELECT ls.loan_id,
                      ls.status_name,
                      ls.status_date + '03:00:00'::interval AS start_stat,
                      CASE
                          WHEN lead(ls.status_date + '03:00:00'::interval)
                               OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id) IS NULL
                              THEN (CURRENT_DATE + 1)::timestamp without time zone
                          ELSE lead(ls.status_date + '03:00:00'::interval)
                               OVER (PARTITION BY ls.loan_id ORDER BY lspm.sc_id)
                          END                               AS stop_stat,
                      p.product_name
               FROM loan_statuses ls
                        JOIN loans l_1 ON l_1.loan_id = ls.loan_id
                        JOIN products p ON l_1.product_id = p.product_id
                        JOIN loan_statuses_pk_map lspm ON ls.status_id = lspm.pz_id
               WHERE ls.is_deleted IS FALSE
                 AND (ls.status_name = ANY
                      (ARRAY ['closed'::loansstatusenum, 'loan_extended'::loansstatusenum, 'loan_overdue'::loansstatusenum, 'loan_issued'::loansstatusenum, 'period_paid'::loansstatusenum, 'cession'::loansstatusenum, 'bankrupt'::loansstatusenum, 'client_died'::loansstatusenum]))) init_data
         WHERE init_data.start_stat <> init_data.stop_stat
     ),
     install_plan_pay AS (
         WITH shed_vers AS (
             SELECT DISTINCT ON (a.loan_id, (a.shed_begin_dt::date)) a.loan_id,
                                                                     a.shed_version,
                                                                     a.shed_begin_dt AS start_shed_dt,
                                                                     CASE
                                                                         WHEN lead(a.shed_begin_dt)
                                                                              OVER (PARTITION BY a.loan_id ORDER BY a.shed_begin_dt) IS NULL
                                                                             THEN (CURRENT_DATE + 1)::timestamp without time zone
                                                                         ELSE lead(a.shed_begin_dt)
                                                                              OVER (PARTITION BY a.loan_id ORDER BY a.shed_begin_dt)
                                                                         END         AS stop_shed_dt
             FROM (SELECT DISTINCT ON (loan_payment_scheme.loan_id, loan_payment_scheme.schedule_number) loan_payment_scheme.loan_id,
                                                                                                         loan_payment_scheme.schedule_number                                     AS shed_version,
                                                                                                         loan_payment_scheme.paid_at + '03:00:00'::interval - '7 days'::interval AS shed_begin_dt
                   FROM loan_payment_scheme
                   ORDER BY loan_payment_scheme.loan_id, loan_payment_scheme.schedule_number,
                            loan_payment_scheme.paid_at) a
             ORDER BY a.loan_id, (a.shed_begin_dt::date), a.shed_begin_dt DESC
         )
         SELECT shed_vers.start_shed_dt,
                shed_vers.stop_shed_dt,
                shed_vers.shed_version,
                lps.loan_id,
                (lps.paid_at + '03:00:00'::interval)::date AS paid_at,
                lps.payment_amount
         FROM shed_vers
                  JOIN loan_payment_scheme lps
                       ON shed_vers.loan_id = lps.loan_id AND shed_vers.shed_version = lps.schedule_number
     ),
     pre_data AS (
         SELECT calendar.check_dt,
                ppc.loan_id,
                ppc.stop_period AS event_dt,
                ppc.product_name,
                CASE
                    WHEN ppc.loan_id IS NOT NULL THEN 'Плановое погашение'::text
                    ELSE NULL::text
                    END         AS event_type
         FROM calendar
                  LEFT JOIN pdl_plan_close ppc ON calendar.check_dt = ppc.stop_period
                  LEFT JOIN statuses ON statuses.loan_id = ppc.loan_id AND
                                        statuses.start_stat > (ppc.start_period + '00:00:01'::interval) AND
                                        statuses.start_stat < ppc.stop_period AND (statuses.status_name = ANY
                                                                                   (ARRAY ['closed'::loansstatusenum, 'loan_extended'::loansstatusenum]))
         WHERE statuses.status_name IS NULL
         UNION ALL
         SELECT calendar.check_dt,
                ipp.loan_id,
                ipp.paid_at,
                CASE
                    WHEN ipp.loan_id IS NOT NULL THEN 'Аннуитет'::text
                    ELSE NULL::text
                    END AS product_name,
                CASE
                    WHEN ipp.loan_id IS NOT NULL THEN 'Плановое погашение'::text
                    ELSE NULL::text
                    END AS event_type
         FROM calendar
                  LEFT JOIN install_plan_pay ipp
                            ON ipp.start_shed_dt < calendar.check_dt AND ipp.stop_shed_dt >= calendar.check_dt AND
                               calendar.check_dt = ipp.paid_at
                  LEFT JOIN statuses
                            ON statuses.loan_id = ipp.loan_id AND statuses.status_name = 'closed'::loansstatusenum AND
                               statuses.start_stat < ipp.paid_at
         WHERE statuses.status_name IS NULL
         UNION ALL
         SELECT calendar.check_dt,
                statuses.loan_id,
                statuses.start_stat,
                statuses.product_name,
                CASE
                    WHEN statuses.loan_id IS NOT NULL THEN 'Выход на просрочку'::text
                    ELSE NULL::text
                    END AS event_type
         FROM calendar
                  LEFT JOIN statuses
                            ON statuses.start_stat = (calendar.check_dt + 1) AND statuses.status_name = 'loan_overdue'::loansstatusenum
     )
SELECT pre_data.check_dt,
       pre_data.loan_id,
       max(pre_data.event_dt)           AS event_dt,
       max(pre_data.product_name::text) AS product_name,
       CASE
           WHEN string_agg(pre_data.event_type, ', '::text) ~~ '%Плановое погашение%'::text AND
                string_agg(pre_data.event_type, ', '::text) !~~ '%Выход на просрочку%'::text THEN 'Плановое погашение'::text
           WHEN string_agg(pre_data.event_type, ', '::text) ~~ '%Выход на просрочку%'::text THEN 'Выход на просрочку'::text
           ELSE string_agg(pre_data.event_type, ', '::text)
           END                          AS event_type,
       max(
               CASE
                   WHEN l.is_loan_repeated = true THEN 'Повторная'::text
                   WHEN l.is_loan_repeated = false THEN 'Первичная'::text
                   ELSE NULL::text
                   END)                 AS is_loan_repeated
FROM pre_data
         LEFT JOIN loans l ON l.loan_id = pre_data.loan_id
GROUP BY pre_data.check_dt, pre_data.loan_id
ORDER BY pre_data.check_dt;

alter materialized view mvw_plan_fact_events owner to "pz-zeppelin";

